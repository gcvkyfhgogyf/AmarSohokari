@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.sohokari

import android.graphics.BitmapFactory
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    val elev = CardDefaults.cardElevation(defaultElevation = 2.dp)
    val shape = RoundedCornerShape(20.dp)
    if (onClick != null) Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, border = border, elevation = elev, content = content)
    else Card(modifier = modifier, shape = shape, colors = colors, border = border, elevation = elev, content = content)
}

@Composable
fun PButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, filled: Boolean = true, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, label = "press")
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick, interactionSource = src, shape = RoundedCornerShape(16.dp),
        color = if (filled) cs.primary else Color.Transparent,
        contentColor = if (filled) cs.onPrimary else cs.primary,
        border = if (filled) null else BorderStroke(1.2.dp, cs.primary),
        shadowElevation = if (filled) 3.dp else 0.dp,
        modifier = modifier.height(50.dp).graphicsLayer { scaleX = sc; scaleY = sc }
    ) {
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) { Icon(icon, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
            Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun StatTile(icon: ImageVector, label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    AppCard(modifier.height(120.dp), onClick) {
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(icon, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(6.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun SectionTitle(t: String, modifier: Modifier = Modifier) {
    Text(t, modifier, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun DetailScaffold(title: String, back: () -> Unit, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton(back) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "পিছনে") } })
    }, content = content)
}

@Composable
fun CoverImage(book: Book, modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(12.dp), showTitle: Boolean = true) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, book.coverPath) {
        value = if (book.coverPath.isBlank()) null
        else withContext(Dispatchers.IO) { BitmapFactory.decodeFile(book.coverPath)?.asImageBitmap() }
    }
    val palettes = listOf(
        listOf(Color(0xFF172B4D), Color(0xFF16866A)), listOf(Color(0xFF16866A), Color(0xFF172B4D)),
        listOf(Color(0xFF172B4D), Color(0xFF3B5B8C)), listOf(Color(0xFF0F5C4A), Color(0xFFC6A66B)))
    val pal = palettes[(book.id % 4).toInt()]
    Box(modifier.clip(shape).background(Brush.linearGradient(pal)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else if (showTitle) Text(book.title, Modifier.padding(10.dp), color = Color.White, fontWeight = FontWeight.Bold,
            fontSize = 15.sp, textAlign = TextAlign.Center, maxLines = 5, overflow = TextOverflow.Ellipsis)
        else Text(book.title.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
    }
}

/** আরবি লাইন ডান থেকে বামে (RTL) ও বড় ফন্টে, বাংলা/ইংরেজি স্বাভাবিকভাবে সাজায়। */
fun readText(text: String): AnnotatedString = buildAnnotatedString {
    for (line in text.split("\n")) {
        val l = if (line.isEmpty()) " " else line
        if (isArabicLine(l)) {
            withStyle(ParagraphStyle(textDirection = TextDirection.Rtl, textAlign = TextAlign.Start, lineHeight = 42.sp)) {
                withStyle(SpanStyle(fontSize = 25.sp)) { append(l) }
            }
        } else {
            withStyle(ParagraphStyle(textDirection = TextDirection.Content, lineHeight = 29.sp)) { append(l) }
        }
    }
}
