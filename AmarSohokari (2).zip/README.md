# আমার সহকারী (Android)

## APK বানানোর নিয়ম (GitHub দিয়ে)
1. GitHub-এ নতুন repository খুলুন।
2. এই ফোল্ডারের সব ফাইল (লুকানো `.github` ফোল্ডারসহ) repository-র মূল জায়গায় আপলোড করুন।
3. **Actions** ট্যাবে "Build APK" চলবে (৫–১০ মিনিট)।
4. কাজ শেষ হলে ওই run খুলে নিচে **Artifacts → AmarSohokari-apk** ডাউনলোড করুন, ZIP খুলে `app-debug.apk` ফোনে ইনস্টল করুন।
