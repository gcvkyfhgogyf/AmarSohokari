package com.amar.sohokari

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Vm(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    private val dao = AppDb.get(app).dao()
    val books = dao.books().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val lessons = dao.lessons().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val scheds = dao.scheds().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val last = dao.lastMsgs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun msgs(b: Long) = dao.msgs(b)

    fun rescheduleAll() = viewModelScope.launch(Dispatchers.IO) {
        dao.schedsNow().filter { it.enabled }.forEach { Scheduler.schedule(ctx, it) }
    }

    fun importBook(uri: Uri?, pasted: String, title: String, author: String, cat: String,
                   mode: Int, n: Int, done: (String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                var fname = "লেখা.txt"
                val units: List<String>
                if (uri != null) { fname = Importer.name(ctx, uri); units = Importer.units(ctx, uri, fname) }
                else units = Importer.paras(pasted)
                if (units.all { it.isBlank() }) {
                    withContext(Dispatchers.Main) { done("কোনো লেখা পাওয়া যায়নি। স্ক্যান করা ছবির পিডিএফ হলে OCR এখনো যুক্ত হয়নি।") }
                    return@launch
                }
                val isPdf = fname.lowercase().endsWith(".pdf")
                val parts = when (mode) {
                    0 -> Splitter.byCount(units, n, if (isPdf) "পৃষ্ঠা" else "অনুচ্ছেদ")
                    1 -> Splitter.byWords(units, n)
                    else -> Splitter.numbered(units.joinToString("\n"), n).ifEmpty { Splitter.byCount(units, n, "অংশ") }
                }
                val name = title.ifBlank { fname.substringBeforeLast('.') }
                val id = dao.insertBook(Book(title = name, author = author, category = cat, assistantName = "$cat সহকারী: $name"))
                dao.insertLessons(parts.mapIndexed { i, p -> Lesson(bookId = id, idx = i, title = p.first, text = p.second) })
                dao.insertMsg(Msg(bookId = id, fromUser = false,
                    text = "আসসালামু আলাইকুম! আমি \"$name\" বইয়ের সহকারী। মোট ${bn(parts.size)}টি পাঠ তৈরি হয়েছে। সময়সূচি ঠিক করলে নির্ধারিত সময়ে পাঠ এখানেই চলে আসবে। এখনই শুরু করতে \"পরবর্তী\" লিখুন।"))
                withContext(Dispatchers.Main) { done(null) }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { done("ত্রুটি: ${e.message}") }
            }
        }
    }

    fun addSched(bookId: Long, h: Int, m: Int) = viewModelScope.launch(Dispatchers.IO) {
        val s = Sched(bookId = bookId, hour = h, minute = m)
        Scheduler.schedule(ctx, s.copy(id = dao.insertSched(s)))
    }
    fun toggleSched(s: Sched, e: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        dao.setSched(s.id, e)
        if (e) Scheduler.schedule(ctx, s) else Scheduler.cancelSched(ctx, s)
    }
    fun delSched(s: Sched) = viewModelScope.launch(Dispatchers.IO) {
        Scheduler.cancelSched(ctx, s); dao.delSched(s.id)
    }
    fun delBook(b: Book) = viewModelScope.launch(Dispatchers.IO) {
        dao.schedsOfBook(b.id).forEach { Scheduler.cancelSched(ctx, it) }
        dao.delScheds(b.id); dao.delMsgs(b.id); dao.delLessons(b.id); dao.delBook(b.id)
    }
    fun sendNow(bookId: Long) = viewModelScope.launch(Dispatchers.IO) { Sender.deliver(ctx, bookId, notify = false) }

    fun markDone(lessonId: Long) = viewModelScope.launch(Dispatchers.IO) {
        dao.setStatus(lessonId, 2, System.currentTimeMillis())
    }
    fun later(lessonId: Long) = viewModelScope.launch(Dispatchers.IO) {
        dao.setStatus(lessonId, 3, 0)
        Scheduler.setAlarm(ctx, (2_000_000 + lessonId).toInt(), System.currentTimeMillis() + 3_600_000L,
            Intent(ctx, AlarmReceiver::class.java).putExtra("type", "later").putExtra("lessonId", lessonId))
    }
    fun userSay(book: Book, text: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.insertMsg(Msg(bookId = book.id, fromUser = true, text = text))
        if (text.contains("পরবর্তী") || text.contains("next", true)) Sender.deliver(ctx, book.id, notify = false)
        else dao.insertMsg(Msg(bookId = book.id, fromUser = false,
            text = "এখন আমি অফলাইনে চলছি। \"পরবর্তী\" লিখলে সঙ্গে সঙ্গে পরবর্তী পাঠ পাঠাব। AI-ভিত্তিক প্রশ্নোত্তর ও পরামর্শ চতুর্থ ধাপে যুক্ত হবে।"))
    }
}
