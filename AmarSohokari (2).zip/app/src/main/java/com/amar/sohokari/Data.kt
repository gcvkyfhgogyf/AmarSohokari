package com.amar.sohokari

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Book(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val author: String = "", val category: String = "সাধারণ বই",
    val assistantName: String, val createdAt: Long = System.currentTimeMillis()
)

// status: 0 = পাঠানো হয়নি, 1 = পাঠানো হয়েছে (অসম্পূর্ণ), 2 = সম্পন্ন, 3 = পরে পড়ব
@Entity(indices = [Index("bookId")])
data class Lesson(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long, val idx: Int, val title: String, val text: String,
    val status: Int = 0, val sentAt: Long = 0, val doneAt: Long = 0
)

@Entity(indices = [Index("bookId")])
data class Msg(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long, val fromUser: Boolean, val text: String,
    val lessonId: Long = 0, val time: Long = System.currentTimeMillis()
)

@Entity
data class Sched(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long, val hour: Int, val minute: Int, val enabled: Boolean = true
)

@Dao
interface AppDao {
    @Insert suspend fun insertBook(b: Book): Long
    @Insert suspend fun insertLessons(l: List<Lesson>)
    @Insert suspend fun insertMsg(m: Msg): Long
    @Insert suspend fun insertSched(s: Sched): Long
    @Query("SELECT * FROM Book ORDER BY id DESC") fun books(): Flow<List<Book>>
    @Query("SELECT * FROM Lesson") fun lessons(): Flow<List<Lesson>>
    @Query("SELECT * FROM Msg WHERE bookId=:b ORDER BY id") fun msgs(b: Long): Flow<List<Msg>>
    @Query("SELECT * FROM Msg WHERE id IN (SELECT MAX(id) FROM Msg GROUP BY bookId)") fun lastMsgs(): Flow<List<Msg>>
    @Query("SELECT * FROM Sched") fun scheds(): Flow<List<Sched>>
    @Query("SELECT * FROM Sched") suspend fun schedsNow(): List<Sched>
    @Query("SELECT * FROM Sched WHERE bookId=:b") suspend fun schedsOfBook(b: Long): List<Sched>
    @Query("SELECT * FROM Sched WHERE id=:id") suspend fun sched(id: Long): Sched?
    @Query("SELECT * FROM Book WHERE id=:id") suspend fun book(id: Long): Book?
    @Query("SELECT * FROM Lesson WHERE id=:id") suspend fun lesson(id: Long): Lesson?
    @Query("SELECT * FROM Lesson WHERE bookId=:b AND status=0 ORDER BY idx LIMIT 1") suspend fun nextLesson(b: Long): Lesson?
    @Query("UPDATE Lesson SET status=1, sentAt=:t WHERE id=:id") suspend fun markSent(id: Long, t: Long)
    @Query("UPDATE Lesson SET status=:s, doneAt=:t WHERE id=:id") suspend fun setStatus(id: Long, s: Int, t: Long)
    @Query("UPDATE Sched SET enabled=:e WHERE id=:id") suspend fun setSched(id: Long, e: Boolean)
    @Query("DELETE FROM Sched WHERE id=:id") suspend fun delSched(id: Long)
    @Query("DELETE FROM Book WHERE id=:id") suspend fun delBook(id: Long)
    @Query("DELETE FROM Lesson WHERE bookId=:id") suspend fun delLessons(id: Long)
    @Query("DELETE FROM Msg WHERE bookId=:id") suspend fun delMsgs(id: Long)
    @Query("DELETE FROM Sched WHERE bookId=:id") suspend fun delScheds(id: Long)
}

@Database(entities = [Book::class, Lesson::class, Msg::class, Sched::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "app.db").build().also { inst = it }
        }
    }
}
