package com.amar.sohokari

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.InputStream
import java.util.zip.ZipInputStream

object Importer {
    fun name(c: Context, u: Uri): String {
        c.contentResolver.query(u, null, null, null, null)?.use {
            if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) return it.getString(i) }
        }
        return "বই"
    }

    fun paras(t: String): List<String> = t.split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    private fun zipEntries(s: InputStream, pick: (String) -> Boolean): List<Pair<String, String>> {
        val r = mutableListOf<Pair<String, String>>()
        ZipInputStream(s).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (pick(e.name)) r.add(e.name to z.readBytes().toString(Charsets.UTF_8))
                e = z.nextEntry
            }
        }
        return r
    }

    private fun strip(x: String): String = x
        .replace(Regex("(?is)<(style|script)[^>]*>.*?</\\1>"), "")
        .replace(Regex("(?i)</(p|div|h[1-6]|li|tr|w:p)>|<br\\s*/?>"), "\n")
        .replace(Regex("<[^>]+>"), "")
        .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'").replace("&amp;", "&")

    /** PDF হলে প্রতিটি পৃষ্ঠা একটি ইউনিট; অন্যথায় প্রতিটি অনুচ্ছেদ একটি ইউনিট। */
    fun units(c: Context, u: Uri, fname: String): List<String> {
        val ext = fname.substringAfterLast('.', "").lowercase()
        val stream = c.contentResolver.openInputStream(u) ?: return emptyList()
        return stream.use { s ->
            when (ext) {
                "pdf" -> {
                    PDFBoxResourceLoader.init(c)
                    PDDocument.load(s).use { d ->
                        val ts = PDFTextStripper()
                        (1..d.numberOfPages).map { p -> ts.startPage = p; ts.endPage = p; ts.getText(d).trim() }
                    }
                }
                "docx" -> paras(zipEntries(s) { it == "word/document.xml" }.joinToString("\n") { strip(it.second) })
                "epub" -> paras(zipEntries(s) {
                    val n = it.lowercase(); n.endsWith(".xhtml") || n.endsWith(".html") || n.endsWith(".htm")
                }.sortedBy { it.first }.joinToString("\n") { strip(it.second) })
                else -> paras(s.readBytes().toString(Charsets.UTF_8))
            }
        }
    }
}

object Splitter {
    fun byCount(u: List<String>, n: Int, unit: String): List<Pair<String, String>> {
        val k = n.coerceAtLeast(1)
        return u.chunked(k).mapIndexed { i, c ->
            val a = i * k + 1; val b = a + c.size - 1
            (if (a == b) "$unit ${bn(a)}" else "$unit ${bn(a)}–${bn(b)}") to c.joinToString("\n\n")
        }
    }

    fun byWords(u: List<String>, w: Int): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val cur = StringBuilder(); var cnt = 0
        for (p in u) {
            cur.append(p).append("\n\n"); cnt += p.split(Regex("\\s+")).size
            if (cnt >= w) { out.add("পাঠ ${bn(out.size + 1)}" to cur.toString().trim()); cur.clear(); cnt = 0 }
        }
        if (cur.isNotBlank()) out.add("পাঠ ${bn(out.size + 1)}" to cur.toString().trim())
        return out
    }

    /** "১. ...", "2) ..." ধরনের নম্বর দেখে আয়াত/হাদিস আলাদা করে। */
    fun numbered(full: String, n: Int): List<Pair<String, String>> {
        val ms = Regex("(?m)^\\s*([0-9০-৯]{1,5})\\s*[-.।):]").findAll(full).toList()
        if (ms.isEmpty()) return emptyList()
        val segs = ms.mapIndexed { i, m ->
            m.groupValues[1] to full.substring(m.range.first, if (i + 1 < ms.size) ms[i + 1].range.first else full.length).trim()
        }
        return segs.chunked(n.coerceAtLeast(1)).map { c ->
            val t = if (c.size == 1) "নম্বর ${c[0].first}" else "নম্বর ${c.first().first}–${c.last().first}"
            t to c.joinToString("\n\n") { it.second }
        }
    }
}
