@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.sohokari

import android.app.TimePickerDialog
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlinx.coroutines.launch

@Composable
fun Library(vm: Vm, nav: (Screen) -> Unit) {
    val books by vm.books.collectAsState()
    val lessons by vm.lessons.collectAsState()
    var add by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Book?>(null) }
    var q by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Text("আমার লাইব্রেরি", Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), singleLine = true,
                placeholder = { Text("বই বা লেখক খুঁজুন…") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
                shape = RoundedCornerShape(26.dp))
            val shown = books.filter { q.isBlank() || it.title.contains(q, true) || it.author.contains(q, true) }
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text("লাইব্রেরি খালি। নিচের বাটনে চাপ দিয়ে বই যোগ করুন।", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                items(shown, key = { it.id }) { b ->
                    val ls = lessons.filter { it.bookId == b.id }
                    val done = ls.count { it.status == 2 }
                    val frac = if (ls.isEmpty()) 0f else done.toFloat() / ls.size
                    Column(Modifier.clickable { nav(Screen.Reader(b.id, b.lastPage)) }, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box {
                            CoverImage(b, Modifier.fillMaxWidth().aspectRatio(0.72f))
                            Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(30.dp).clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.4f)).clickable { sel = b }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.MoreVert, "মেনু", Modifier.size(18.dp), tint = Color.White)
                            }
                        }
                        Text(b.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(if (b.author.isBlank()) b.category else b.author, fontSize = 12.sp, maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, overflow = TextOverflow.Ellipsis)
                        Text((if (b.pages > 0) "${bn(b.pages)} পৃষ্ঠা • " else "") + "${bn((frac * 100).toInt())}% সম্পন্ন", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)))
                        if (b.ocrTotal > 0 && b.ocrDone < b.ocrTotal)
                            Text("OCR চলছে ${bn(b.ocrDone)}/${bn(b.ocrTotal)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
        ExtendedFloatingActionButton(onClick = { add = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
            icon = { Icon(Icons.Rounded.Add, null) }, text = { Text("বই যোগ করুন", fontWeight = FontWeight.SemiBold) })
    }
    if (add) AddBookDialog(vm) { add = false }
    sel?.let { BookDialog(vm, it) { sel = null } }
}

@Composable
fun AddBookDialog(vm: Vm, close: () -> Unit) {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fname by remember { mutableStateOf("") }
    var pasted by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("সাধারণ বই") }
    var mode by remember { mutableIntStateOf(0) }
    var n by remember { mutableStateOf("5") }
    var forceOcr by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val isPdf = fname.lowercase().endsWith(".pdf")
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { uri = u; fname = Importer.name(ctx, u); if (title.isBlank()) title = fname.substringBeforeLast('.') }
    }
    AlertDialog(onDismissRequest = { if (!busy) close() },
        title = { Text("নতুন বই যোগ করুন") },
        confirmButton = {
            Button(enabled = !busy && (uri != null || pasted.isNotBlank()), onClick = {
                busy = true; err = null
                vm.importBook(uri, pasted, title, author, cat, if (isPdf) 0 else mode, n.toIntOrNull() ?: 5, forceOcr) { e ->
                    busy = false
                    if (e == null) { close() } else { err = e }
                }
            }) { Text(if (busy) "প্রস্তুত হচ্ছে…" else "সংরক্ষণ") }
        },
        dismissButton = { TextButton({ if (!busy) close() }) { Text("বাতিল") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PButton(if (fname.isBlank()) "ফাইল বাছুন (PDF/TXT/EPUB/DOCX)" else fname, Modifier.fillMaxWidth(), Icons.Rounded.Description, filled = false) {
                    picker.launch(arrayOf("*/*"))
                }
                Text("অথবা লেখা পেস্ট করুন:", fontSize = 13.sp)
                OutlinedTextField(pasted, { pasted = it }, Modifier.fillMaxWidth(), minLines = 3, maxLines = 6)
                OutlinedTextField(title, { title = it }, label = { Text("বইয়ের নাম") }, singleLine = true)
                OutlinedTextField(author, { author = it }, label = { Text("লেখক") }, singleLine = true)
                Text("বিভাগ:", fontSize = 13.sp)
                listOf("সাধারণ বই", "কুরআন", "হাদিস", "ইংরেজি", "গণিত").chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { c -> FilterChip(cat == c, { cat = c; if (c == "কুরআন" || c == "হাদিস") { mode = 2 } }, { Text(c) }) }
                    }
                }
                if (isPdf) {
                    Text("PDF: প্রতি পাঠে কত পৃষ্ঠা? (প্রতিটি পৃষ্ঠার সম্পূর্ণ লেখা মেসেজে যাবে)", fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(forceOcr, { forceOcr = it })
                        Text("স্ক্যান/লেখা এলোমেলো হলে সব পৃষ্ঠায় OCR চালান", fontSize = 13.sp)
                    }
                } else {
                    Text("পাঠ ভাগ করার নিয়ম:", fontSize = 13.sp)
                    listOf("প্রতি পাঠে N অনুচ্ছেদ", "প্রতি পাঠে N শব্দ", "নম্বর ধরে (আয়াত/হাদিস) N টি").forEachIndexed { i, l ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(mode == i, { mode = i; n = if (i == 1) "200" else "5" }); Text(l, fontSize = 14.sp)
                        }
                    }
                }
                OutlinedTextField(n, { n = it.filter { c -> c.isDigit() } }, label = { Text("N = ") }, singleLine = true)
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        })
}

@Composable
fun BookDialog(vm: Vm, b: Book, close: () -> Unit) {
    val ctx = LocalContext.current
    val scheds by vm.scheds.collectAsState()
    val mine = scheds.filter { it.bookId == b.id }.sortedBy { it.hour * 60 + it.minute }
    var confirm by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf(b.title) }
    var author by remember { mutableStateOf(b.author) }
    AlertDialog(onDismissRequest = close, title = { Text("বইয়ের সেটিংস") },
        confirmButton = { TextButton(close) { Text("বন্ধ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("বইয়ের নাম") }, singleLine = true)
                OutlinedTextField(author, { author = it }, label = { Text("লেখক") }, singleLine = true)
                PButton("তথ্য সংরক্ষণ", Modifier.fillMaxWidth(), Icons.Rounded.Edit, filled = false) { vm.updateBook(b, title, author); close() }
                HorizontalDivider()
                Text("সময়সূচি:", fontWeight = FontWeight.SemiBold)
                if (mine.isEmpty()) Text("কোনো সময় ঠিক করা নেই", fontSize = 13.sp)
                mine.forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(timeLabel(s.hour, s.minute), Modifier.weight(1f))
                        Switch(s.enabled, { vm.toggleSched(s, it) })
                        IconButton({ vm.delSched(s) }) { Icon(Icons.Rounded.Delete, "মুছুন") }
                    }
                }
                PButton("নতুন সময় যোগ করুন", Modifier.fillMaxWidth(), Icons.Rounded.Add) {
                    TimePickerDialog(ctx, { _, h, m -> vm.addSched(b.id, h, m) }, 9, 0, false).show()
                }
                PButton("এখনই পরবর্তী পাঠ পাঠাও", Modifier.fillMaxWidth(), Icons.Rounded.ChatBubble, filled = false) { vm.sendNow(b.id); close() }
                if (b.pdfPath.isNotBlank())
                    PButton("আবার OCR চালান", Modifier.fillMaxWidth(), Icons.Rounded.AutoStories, filled = false) { vm.reOcr(b); close() }
                if (!confirm) TextButton({ confirm = true }) { Text("বইটি মুছে ফেলুন", color = MaterialTheme.colorScheme.error) }
                else Button({ vm.delBook(b); close() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("হ্যাঁ, নিশ্চিত মুছুন") }
            }
        })
}

@Composable
fun ReaderScreen(vm: Vm, bookId: Long, startPage: Int, back: () -> Unit) {
    val books by vm.books.collectAsState()
    val book = books.find { it.id == bookId }
    if (book == null) {
        DetailScaffold("বই", back) { p -> Box(Modifier.padding(p).fillMaxSize(), contentAlignment = Alignment.Center) { Text("বই পাওয়া যায়নি") } }
    } else if (book.pdfPath.isBlank() || !File(book.pdfPath).exists()) {
        TextReader(vm, book, back)
    } else {
        PdfReader(vm, book, startPage, back)
    }
}

@Composable
fun TextReader(vm: Vm, book: Book, back: () -> Unit) {
    val lessons by vm.lessons.collectAsState()
    val mine = lessons.filter { it.bookId == book.id }.sortedBy { it.idx }
    DetailScaffold(book.title, back) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            if (book.pdfPath.isBlank() && book.pages > 0)
                item { Text("এই বইয়ের মূল PDF সংরক্ষিত নেই (পুরোনো সংস্করণে যোগ করা)। বইটি মুছে PDF আবার যোগ করলে মূল PDF পড়া যাবে।", color = MaterialTheme.colorScheme.secondary) }
            items(count = mine.size) { i ->
                val l = mine[i]
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(l.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
                    Text(readText(l.text.ifBlank { "(লেখা এখনো প্রস্তুত নয়)" }), fontSize = 18.sp)
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
fun PdfPage(s: PdfSession, i: Int, px: Int) {
    val bmp by produceState<Bitmap?>(null, i, px) { value = try { s.page(i, px) } catch (e: Exception) { null } }
    val b = bmp
    val ratio = if (b != null) b.width.toFloat() / b.height else 0.707f
    Box(Modifier.fillMaxWidth().aspectRatio(ratio).background(Color.White), contentAlignment = Alignment.Center) {
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize()) else CircularProgressIndicator(Modifier.size(28.dp))
    }
}

@Composable
fun PdfReader(vm: Vm, book: Book, startPage: Int, back: () -> Unit) {
    val session = remember(book.pdfPath) { try { PdfSession(File(book.pdfPath)) } catch (e: Exception) { null } }
    DisposableEffect(session) { onDispose { session?.close() } }
    if (session == null) {
        DetailScaffold(book.title, back) { p -> Box(Modifier.padding(p).fillMaxSize(), contentAlignment = Alignment.Center) { Text("PDF খোলা যায়নি") } }
        return
    }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = startPage.coerceIn(0, (session.count - 1).coerceAtLeast(0)))
    var zoom by remember { mutableFloatStateOf(1f) }
    var jump by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val cur by remember { derivedStateOf { state.firstVisibleItemIndex } }
    LaunchedEffect(state) { snapshotFlow { state.firstVisibleItemIndex }.collect { vm.saveLastPage(book.id, it) } }
    Scaffold(topBar = {
        TopAppBar(
            title = {
                Column {
                    Text(book.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("পৃষ্ঠা ${bn(cur + 1)} / ${bn(session.count)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            navigationIcon = { IconButton(back) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "পিছনে") } },
            actions = {
                IconButton({ zoom = (zoom - 0.5f).coerceAtLeast(1f) }) { Icon(Icons.Rounded.ZoomOut, "জুম আউট") }
                IconButton({ zoom = (zoom + 0.5f).coerceAtMost(3f) }) { Icon(Icons.Rounded.ZoomIn, "জুম ইন") }
                IconButton({ jump = true }) { Icon(Icons.Rounded.Search, "পৃষ্ঠায় যান") }
            })
    }) { p ->
        BoxWithConstraints(Modifier.padding(p).fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) {
            val w = (maxWidth - 16.dp) * zoom
            val px = with(LocalDensity.current) { w.toPx() }.toInt().coerceIn(300, 3000)
            Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
                LazyColumn(Modifier.width(w).fillMaxHeight(), state = state, verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(count = session.count) { i -> PdfPage(session, i, px) }
                }
            }
        }
    }
    if (jump) {
        var t by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { jump = false }, title = { Text("পৃষ্ঠায় যান") },
            text = { OutlinedTextField(t, { t = it.filter { c -> c.isDigit() } }, label = { Text("১ থেকে ${bn(session.count)}") }, singleLine = true) },
            confirmButton = {
                TextButton({
                    val n = t.toIntOrNull()
                    if (n != null && n in 1..session.count) { scope.launch { state.scrollToItem(n - 1) }; jump = false }
                }) { Text("যান") }
            },
            dismissButton = { TextButton({ jump = false }) { Text("বাতিল") } })
    }
}
