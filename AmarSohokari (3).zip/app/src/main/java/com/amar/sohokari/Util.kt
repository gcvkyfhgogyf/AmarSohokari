package com.amar.sohokari

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun bn(s: String): String = s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")
fun bn(n: Int): String = bn(n.toString())
fun bn(n: Long): String = bn(n.toString())

fun timeLabel(h: Int, m: Int): String {
    val p = when { h < 5 -> "রাত"; h < 12 -> "সকাল"; h < 16 -> "দুপুর"; h < 18 -> "বিকেল"; else -> "রাত" }
    val hh = if (h % 12 == 0) 12 else h % 12
    return "$p ${bn(hh)}:${bn(m.toString().padStart(2, '0'))}"
}

fun fmtDate(t: Long): String = bn(SimpleDateFormat("d MMM yyyy", Locale.forLanguageTag("bn")).format(Date(t)))
fun fmtTime(t: Long): String = bn(SimpleDateFormat("hh:mm a", Locale.forLanguageTag("bn")).format(Date(t)))

fun startOfDay(t: Long): Long = Calendar.getInstance().apply {
    timeInMillis = t; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun prevDay(t: Long): Long = Calendar.getInstance().apply { timeInMillis = t; add(Calendar.DAY_OF_YEAR, -1) }.timeInMillis

fun doneDays(l: List<Lesson>): List<Long> = l.filter { it.status == 2 && it.doneAt > 0 }.map { startOfDay(it.doneAt) }.distinct().sorted()

fun streak(l: List<Lesson>, now: Long): Int {
    val days = doneDays(l).toSet()
    var d = startOfDay(now)
    if (d !in days) d = startOfDay(prevDay(d))
    var c = 0
    while (d in days) { c++; d = startOfDay(prevDay(d)) }
    return c
}

fun maxStreak(l: List<Lesson>): Int {
    val days = doneDays(l)
    var best = 0; var run = 0; var prev = 0L
    for (d in days) {
        run = if (prev != 0L && startOfDay(prevDay(d)) == prev) run + 1 else 1
        if (run > best) best = run
        prev = d
    }
    return best
}

fun isArabicLine(s: String): Boolean {
    var ar = 0; var letters = 0
    for (ch in s) {
        if (ch.isLetter()) {
            letters++
            if (ch in '\u0600'..'\u06FF' || ch in '\u0750'..'\u077F' || ch in '\uFB50'..'\uFDFF' || ch in '\uFE70'..'\uFEFF') ar++
        }
    }
    return letters > 0 && ar * 2 > letters
}
