@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.sohokari

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class Screen {
    object Today : Screen()
    object Done : Screen()
    object Pending : Screen()
    object BooksList : Screen()
    object Streak : Screen()
    data class Reader(val bookId: Long, val page: Int) : Screen()
}

class MainActivity : ComponentActivity() {
    private val vm: Vm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.channel(this)
        val openBook = intent.getLongExtra("bookId", -1)
        val prefs = getSharedPreferences("p", 0)
        setContent {
            var theme by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            AppTheme(theme) { App(vm, openBook, theme) { theme = it; prefs.edit().putInt("theme", it).apply() } }
        }
    }
}

@Composable
fun Splash() {
    Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.ic_logo_fg), null, Modifier.size(170.dp))
            Text("আমার সহকারী", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("পড়াশোনা • সময় • অভ্যাস", color = Gold, fontSize = 13.sp)
        }
    }
}

@Composable
fun App(vm: Vm, openBook: Long, theme: Int, setTheme: (Int) -> Unit) {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(900); splash = false }
    if (splash) Splash() else Main(vm, openBook, theme, setTheme)
}

@Composable
fun Main(vm: Vm, openBook: Long, theme: Int, setTheme: (Int) -> Unit) {
    var tab by remember { mutableIntStateOf(if (openBook > 0) 1 else 0) }
    var chatId by remember { mutableLongStateOf(openBook) }
    var screen by remember { mutableStateOf<Screen?>(null) }
    val books by vm.books.collectAsState()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        vm.rescheduleAll()
    }
    BackHandler(enabled = screen != null) { screen = null }
    val s = screen
    if (s != null) { ScreenHost(vm, s, { screen = null }, { screen = it }); return }
    val chatBook = books.find { it.id == chatId }
    if (chatBook != null && tab == 1) { ChatScreen(vm, chatBook, { chatId = -1 }, { screen = it }); return }
    val items = listOf(
        Icons.Rounded.Home to "হোম", Icons.Rounded.ChatBubble to "মেসেঞ্জার", Icons.Rounded.AutoStories to "লাইব্রেরি",
        Icons.Rounded.BarChart to "অগ্রগতি", Icons.Rounded.Settings to "সেটিংস")
    Scaffold(bottomBar = {
        NavigationBar {
            items.forEachIndexed { i, (ic, l) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i; chatId = -1 },
                    icon = { Icon(ic, l) }, label = { Text(l, fontSize = 11.sp, maxLines = 1) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Home(vm, { screen = it }, { tab = it })
                1 -> Messenger(vm) { chatId = it }
                2 -> Library(vm) { screen = it }
                3 -> ProgressScreen(vm) { screen = it }
                else -> SettingsScreen(vm, theme, setTheme)
            }
        }
    }
}

@Composable
fun ScreenHost(vm: Vm, s: Screen, back: () -> Unit, nav: (Screen) -> Unit) {
    when (s) {
        is Screen.Today -> TodayScreen(vm, back, nav)
        is Screen.Done -> DoneScreen(vm, back, nav)
        is Screen.Pending -> PendingScreen(vm, back, nav)
        is Screen.BooksList -> BooksScreen(vm, back, nav)
        is Screen.Streak -> StreakScreen(vm, back)
        is Screen.Reader -> ReaderScreen(vm, s.bookId, s.page, back)
    }
}

@Composable
fun Home(vm: Vm, nav: (Screen) -> Unit, goTab: (Int) -> Unit) {
    val ctx = LocalContext.current
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val scheds by vm.scheds.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val ytEnd = prefs.getLong("yt_end", 0)
    val day0 = startOfDay(now)
    val sentToday = lessons.count { it.sentAt >= day0 }
    val doneToday = lessons.count { it.status == 2 && it.doneAt >= day0 }
    val doneAll = lessons.count { it.status == 2 }
    val incomplete = lessons.count { it.status == 1 || it.status == 3 }
    val nextS = scheds.filter { it.enabled }.minByOrNull { Scheduler.nextTrigger(it.hour, it.minute) }
    val nextBook = books.find { it.id == nextS?.bookId }
    val nextLesson = lessons.filter { it.bookId == nextBook?.id && it.status == 0 }.minByOrNull { it.idx }
    val dateFmt = remember { SimpleDateFormat("EEEE, d MMMM yyyy", Locale.forLanguageTag("bn")) }
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.forLanguageTag("bn")) }
    var dlg by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Navy), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.ic_logo_fg), null, Modifier.size(54.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("আমার সহকারী", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(bn(dateFmt.format(Date(now))), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Navy, Color(0xFF1B5D6B), Emerald)))) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(bn(timeFmt.format(Date(now))), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Text("আজকের অগ্রগতি  •  ${bn(doneToday)}/${bn(sentToday)} সম্পন্ন", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                val f = if (sentToday == 0) 0f else (doneToday.toFloat() / sentToday).coerceIn(0f, 1f)
                LinearProgressIndicator(progress = { f }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = Gold, trackColor = Color.White.copy(alpha = 0.25f))
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                Text("পরবর্তী পড়া: " + (nextS?.let { timeLabel(it.hour, it.minute) } ?: "সময় ঠিক করা নেই"), color = Color.White, fontSize = 14.sp)
                Text("বিষয়: " + (nextBook?.title ?: "—") + (nextLesson?.let { " • " + it.title } ?: ""), color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, maxLines = 2)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Icons.Rounded.Today, "আজকের মোট পড়া", bn(sentToday), Modifier.weight(1f)) { nav(Screen.Today) }
            StatTile(Icons.Rounded.CheckCircle, "সম্পূর্ণ পড়া", bn(doneAll), Modifier.weight(1f)) { nav(Screen.Done) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Icons.Rounded.PendingActions, "অসম্পূর্ণ পড়া", bn(incomplete), Modifier.weight(1f)) { nav(Screen.Pending) }
            StatTile(Icons.Rounded.AutoStories, "মোট বই", bn(books.size), Modifier.weight(1f)) { nav(Screen.BooksList) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(Icons.Rounded.LocalFireDepartment, "ধারাবাহিক দিন", bn(streak(lessons, now)), Modifier.weight(1f)) { nav(Screen.Streak) }
            val remText = if (ytEnd > now) { val r = (ytEnd - now) / 1000; "${bn(r / 60)}:${bn(r % 60 / 10)}${bn(r % 10)}" } else "বন্ধ"
            StatTile(Icons.Rounded.Timer, "স্ক্রিন লক টাইমার", remText, Modifier.weight(1f)) { dlg = true }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PButton("পড়া শুরু করুন", Modifier.weight(1f), Icons.Rounded.ChatBubble) { goTab(1) }
            PButton("বই যোগ করুন", Modifier.weight(1f), Icons.Rounded.Add, filled = false) { goTab(2) }
        }
    }
    if (dlg) {
        val opts = listOf("৫ মিনিট" to 5, "১০ মিনিট" to 10, "১৫ মিনিট" to 15, "২০ মিনিট" to 20, "৩০ মিনিট" to 30,
            "৪৫ মিনিট" to 45, "১ ঘণ্টা" to 60, "১ ঘণ্টা ৩০ মিনিট" to 90)
        var custom by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { dlg = false }, confirmButton = { TextButton({ dlg = false }) { Text("বন্ধ") } },
            title = { Text("স্ক্রিন লক টাইমার") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("সময় শেষ হলে চলমান যেকোনো অ্যাপ থেকে বের হয়ে হোম স্ক্রিনে যাবে; সেটিংসে চালু থাকলে ফোন লক হবে।", fontSize = 13.sp)
                    if (ytEnd > now) TextButton({ LockTimer.cancel(ctx); dlg = false }) { Text("চলমান টাইমার বাতিল করুন") }
                    opts.forEach { (l, m) -> TextButton({ LockTimer.start(ctx, m); dlg = false }) { Text(l) } }
                    OutlinedTextField(custom, { custom = it.filter { c -> c.isDigit() } }, label = { Text("কাস্টম (মিনিট)") }, singleLine = true)
                    TextButton({ custom.toIntOrNull()?.takeIf { it > 0 }?.let { LockTimer.start(ctx, it); dlg = false } }) { Text("কাস্টম সময় চালু করুন") }
                }
            })
    }
}
