@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.sohokari

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun StatusChip(status: Int) {
    val cs = MaterialTheme.colorScheme
    val (label, bg, fg) = when (status) {
        2 -> Triple("সম্পন্ন", cs.primaryContainer, cs.primary)
        1 -> Triple("অসম্পূর্ণ", Gold.copy(alpha = 0.2f), cs.secondary)
        3 -> Triple("পরে পড়ব", Gold.copy(alpha = 0.2f), cs.secondary)
        else -> Triple("বাকি", cs.surfaceVariant, cs.onSurfaceVariant)
    }
    Surface(shape = RoundedCornerShape(10.dp), color = bg) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun LessonRow(vm: Vm, l: Lesson, book: Book?, nav: (Screen) -> Unit) {
    var exp by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("d MMM yyyy, hh:mm a", Locale.forLanguageTag("bn")) }
    AppCard(Modifier.fillMaxWidth(), onClick = { exp = !exp }) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(book?.title ?: "", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(l.title, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                StatusChip(l.status)
            }
            if (l.sentAt > 0) Text("পাঠানো: " + bn(fmt.format(Date(l.sentAt))), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (l.status == 2) Text("সম্পন্ন: " + bn(fmt.format(Date(l.doneAt))), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            if (exp) {
                HorizontalDivider()
                if (l.text.isBlank()) Text("লেখা এখনো প্রস্তুত নয় (OCR চলছে)…", color = MaterialTheme.colorScheme.secondary)
                else Text(readText(l.text), fontSize = 17.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (l.status != 2) PButton("পড়া সম্পন্ন করুন", Modifier.weight(1f), Icons.Rounded.CheckCircle) { vm.markDone(l.id) }
                    if (book != null && book.pdfPath.isNotBlank() && l.pageFrom > 0)
                        PButton("মূল বই খুলুন", Modifier.weight(1f), Icons.Rounded.AutoStories, filled = false) { nav(Screen.Reader(book.id, l.pageFrom - 1)) }
                }
            } else Text("পড়তে ও বিস্তারিত দেখতে চাপুন", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun TodayScreen(vm: Vm, back: () -> Unit, nav: (Screen) -> Unit) {
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val scheds by vm.scheds.collectAsState()
    val day0 = startOfDay(System.currentTimeMillis())
    val today = lessons.filter { it.sentAt >= day0 }.sortedByDescending { it.sentAt }
    val upcoming = scheds.filter { it.enabled && Scheduler.nextTrigger(it.hour, it.minute) < day0 + 86_400_000L }
        .sortedBy { it.hour * 60 + it.minute }
    DetailScaffold("আজকের মোট পড়া", back) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text("মোট ${bn(today.size)}টি • সম্পন্ন ${bn(today.count { it.status == 2 })}টি • অসম্পূর্ণ ${bn(today.count { it.status != 2 })}টি",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (today.isEmpty()) item { Text("আজ এখনো কোনো পড়া আসেনি।") }
            items(count = today.size) { i -> val l = today[i]; LessonRow(vm, l, books.find { it.id == l.bookId }, nav) }
            item { SectionTitle("আজ বাকি সময়সূচি", Modifier.padding(top = 8.dp)) }
            if (upcoming.isEmpty()) item { Text("আজকের আর কোনো সময়সূচি নেই।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(count = upcoming.size) { i ->
                val s = upcoming[i]
                val b = books.find { it.id == s.bookId }
                val nl = lessons.filter { it.bookId == s.bookId && it.status == 0 }.minByOrNull { it.idx }
                AppCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Schedule, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(timeLabel(s.hour, s.minute), fontWeight = FontWeight.Bold)
                            Text((b?.title ?: "") + (nl?.let { " • " + it.title } ?: ""), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DoneScreen(vm: Vm, back: () -> Unit, nav: (Screen) -> Unit) {
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val done = lessons.filter { it.status == 2 }
    val groups = done.groupBy { startOfDay(it.doneAt) }.toList().sortedByDescending { it.first }
    val fmt = remember { SimpleDateFormat("d MMMM yyyy", Locale.forLanguageTag("bn")) }
    DetailScaffold("সম্পূর্ণ পড়া", back) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("এখন পর্যন্ত মোট ${bn(done.size)}টি পড়া সম্পন্ন হয়েছে।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (done.isEmpty()) item { Text("এখনো কোনো পড়া সম্পন্ন করা হয়নি।") }
            groups.forEach { (day, ls) ->
                val sorted = ls.sortedByDescending { it.doneAt }
                item(key = "h$day") { SectionTitle(bn(fmt.format(Date(day))) + " (${bn(ls.size)}টি)", Modifier.padding(top = 6.dp)) }
                items(count = sorted.size, key = { sorted[it].id }) { i -> val l = sorted[i]; LessonRow(vm, l, books.find { it.id == l.bookId }, nav) }
            }
        }
    }
}

@Composable
fun PendingScreen(vm: Vm, back: () -> Unit, nav: (Screen) -> Unit) {
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val pend = lessons.filter { it.status == 1 || it.status == 3 }.sortedBy { it.sentAt }
    DetailScaffold("অসম্পূর্ণ পড়া", back) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("${bn(pend.size)}টি পড়া এখনো সম্পন্ন হয়নি। চাপ দিয়ে পড়ুন ও সম্পন্ন করুন।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (pend.isEmpty()) item { Text("কোনো অসম্পূর্ণ পড়া নেই 🎉") }
            items(count = pend.size, key = { pend[it].id }) { i -> val l = pend[i]; LessonRow(vm, l, books.find { it.id == l.bookId }, nav) }
        }
    }
}

@Composable
fun BooksScreen(vm: Vm, back: () -> Unit, nav: (Screen) -> Unit) {
    val books by vm.books.collectAsState()
    val lessons by vm.lessons.collectAsState()
    DetailScaffold("মোট বই", back) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("লাইব্রেরিতে মোট ${bn(books.size)}টি বই আছে।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(count = books.size, key = { books[it].id }) { i ->
                val b = books[i]
                val ls = lessons.filter { it.bookId == b.id }
                val frac = if (ls.isEmpty()) 0f else ls.count { it.status == 2 }.toFloat() / ls.size
                AppCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Reader(b.id, b.lastPage)) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        CoverImage(b, Modifier.width(60.dp).height(84.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(b.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(if (b.author.isBlank()) b.category else b.author, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text((if (b.pages > 0) "${bn(b.pages)} পৃষ্ঠা • " else "") + "${bn((frac * 100).toInt())}% সম্পন্ন", fontSize = 12.sp)
                            LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)))
                        }
                    }
                }
            }
        }
    }
}

private val monthNames = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
private val weekShort = listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি")

private fun dayStart(y: Int, m: Int, d: Int): Long =
    Calendar.getInstance().apply { set(y, m, d, 0, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis

@Composable
fun StreakScreen(vm: Vm, back: () -> Unit) {
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val now = System.currentTimeMillis()
    val today0 = startOfDay(now)
    val days = lessons.filter { it.status == 2 }.groupBy { startOfDay(it.doneAt) }
    val daySet = days.keys
    var maxS = 0; var run = 0; var prev = 0L
    for (d in daySet.sorted()) {
        run = if (prev != 0L && startOfDay(prevDay(d)) == prev) run + 1 else 1
        if (run > maxS) maxS = run
        prev = d
    }
    val cal0 = Calendar.getInstance()
    var year by remember { mutableIntStateOf(cal0.get(Calendar.YEAR)) }
    var month by remember { mutableIntStateOf(cal0.get(Calendar.MONTH)) }
    var selected by remember { mutableStateOf<Long?>(null) }
    val first = Calendar.getInstance().apply { set(year, month, 1, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
    val offset = first.get(Calendar.DAY_OF_WEEK) - 1
    val dim = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val rows = (offset + dim + 6) / 7
    val firstRead = daySet.minOrNull()
    val missed = (1..dim).filter { d ->
        val ds = dayStart(year, month, d)
        firstRead != null && ds >= firstRead && ds < today0 && ds !in daySet
    }
    val cs = MaterialTheme.colorScheme
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.forLanguageTag("bn")) }
    DetailScaffold("ধারাবাহিক দিন", back) { p ->
        LazyColumn(Modifier.padding(p).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatTile(Icons.Rounded.Today, "মোট পড়ার দিন", bn(daySet.size), Modifier.weight(1f)) {}
                    StatTile(Icons.Rounded.LocalFireDepartment, "বর্তমান ধারা", bn(streak(lessons, now)), Modifier.weight(1f)) {}
                    StatTile(Icons.Rounded.CheckCircle, "সর্বোচ্চ ধারা", bn(maxS), Modifier.weight(1f)) {}
                }
            }
            item {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton({ if (month == 0) { month = 11; year -= 1 } else { month -= 1 } }) { Icon(Icons.Rounded.ChevronLeft, "আগের মাস") }
                            Text("${monthNames[month]} ${bn(year)}", Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            IconButton({ if (month == 11) { month = 0; year += 1 } else { month += 1 } }) { Icon(Icons.Rounded.ChevronRight, "পরের মাস") }
                        }
                        Row { weekShort.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, color = cs.onSurfaceVariant) } }
                        for (r in 0 until rows) {
                            Row {
                                for (c in 0 until 7) {
                                    val day = r * 7 + c - offset + 1
                                    Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                                        if (day in 1..dim) {
                                            val ds = dayStart(year, month, day)
                                            val read = ds in daySet
                                            var m = Modifier.fillMaxSize().clip(CircleShape).background(if (read) cs.primary else Color.Transparent)
                                            if (ds == today0) m = m.border(1.5.dp, cs.secondary, CircleShape)
                                            Box(m.clickable { selected = ds }, contentAlignment = Alignment.Center) {
                                                Text(bn(day), fontSize = 13.sp, color = if (read) cs.onPrimary else if (ds > today0) cs.onSurfaceVariant.copy(alpha = 0.5f) else cs.onSurface)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Text("সবুজ = পড়েছি, সোনালি বৃত্ত = আজ", fontSize = 11.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
            item {
                Text(if (missed.isEmpty()) "এই মাসে কোনো দিন বাদ পড়েনি।" else "এই মাসে পড়া হয়নি: " + missed.joinToString(", ") { bn(it) } + " তারিখ",
                    fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
            val sel = selected
            if (sel != null) {
                val ls = (days[sel] ?: emptyList()).sortedBy { it.doneAt }
                item { SectionTitle("${bn(SimpleDateFormat("d MMMM yyyy", Locale.forLanguageTag("bn")).format(Date(sel)))} — ${bn(ls.size)}টি পড়া") }
                if (ls.isEmpty()) item { Text("এই দিনে কোনো পড়া সম্পন্ন হয়নি।") }
                items(count = ls.size) { i ->
                    val l = ls[i]
                    AppCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(books.find { it.id == l.bookId }?.title ?: "", fontSize = 12.sp, color = cs.secondary)
                            Text(l.title, fontWeight = FontWeight.Bold)
                            Text("সম্পন্ন: " + bn(timeFmt.format(Date(l.doneAt))), fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProgressScreen(vm: Vm, nav: (Screen) -> Unit) {
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val now = System.currentTimeMillis()
    val d0 = startOfDay(now)
    val done = lessons.filter { it.status == 2 }
    val pend = lessons.count { it.status == 1 || it.status == 3 }
    val days = (0..6).map { i -> var s = d0; repeat(i) { s = startOfDay(prevDay(s)) }; s }.reversed()
    val week = days.map { s -> done.count { it.doneAt >= s && it.doneAt < s + 86_400_000L } }
    val month = done.count { it.doneAt >= d0 - 29 * 86_400_000L }
    val maxW = (week.maxOrNull() ?: 0).coerceAtLeast(1)
    val cs = MaterialTheme.colorScheme
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("অগ্রগতি", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(Icons.Rounded.AutoStories, "মোট বই", bn(books.size), Modifier.weight(1f)) { nav(Screen.BooksList) }
                StatTile(Icons.Rounded.CheckCircle, "সম্পন্ন", bn(done.size), Modifier.weight(1f)) { nav(Screen.Done) }
                StatTile(Icons.Rounded.PendingActions, "অসম্পূর্ণ", bn(pend), Modifier.weight(1f)) { nav(Screen.Pending) }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("সাপ্তাহিক পড়া", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("গত ৭ দিনে ${bn(week.sum())}টি • গত ৩০ দিনে ${bn(month)}টি", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        days.forEachIndexed { i, ds ->
                            val label = Calendar.getInstance().apply { timeInMillis = ds }.get(Calendar.DAY_OF_WEEK) - 1
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                Text(bn(week[i]), fontSize = 11.sp, color = cs.onSurfaceVariant)
                                Box(Modifier.width(26.dp).height((90f * week[i] / maxW + 4f).dp).clip(RoundedCornerShape(8.dp))
                                    .background(if (week[i] > 0) cs.primary else cs.outlineVariant))
                                Spacer(Modifier.height(4.dp))
                                Text(weekShort[label], fontSize = 10.sp, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        item {
            PButton("ধারাবাহিকতা ও ক্যালেন্ডার", Modifier.fillMaxWidth(), Icons.Rounded.LocalFireDepartment) { nav(Screen.Streak) }
        }
        item { SectionTitle("বই অনুযায়ী অগ্রগতি") }
        items(count = books.size, key = { books[it].id }) { i ->
            val b = books[i]
            val ls = lessons.filter { it.bookId == b.id }
            val dn = ls.count { it.status == 2 }
            AppCard(Modifier.fillMaxWidth(), onClick = { nav(Screen.Reader(b.id, b.lastPage)) }) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(b.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    LinearProgressIndicator(progress = { if (ls.isEmpty()) 0f else dn.toFloat() / ls.size }, Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
                    Text("${bn(dn)}/${bn(ls.size)} পাঠ সম্পন্ন", fontSize = 12.sp, color = cs.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: Vm, theme: Int, setTheme: (Int) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var lock by remember { mutableStateOf(prefs.getBoolean("lock", false)) }
    val scheds by vm.scheds.collectAsState()
    val books by vm.books.collectAsState()
    val cs = MaterialTheme.colorScheme
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("সেটিংস", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("থিম", fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("সিস্টেম", "লাইট", "ডার্ক").forEachIndexed { i, l -> FilterChip(theme == i, { setTheme(i) }, { Text(l) }) }
                    }
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("স্ক্রিন লক টাইমার", fontWeight = FontWeight.Bold)
                    Text("সময় শেষ হলে চলমান যেকোনো অ্যাপ (ইউটিউব, ফেসবুক, গেম ইত্যাদি) থেকে বের হয়ে হোম স্ক্রিনে যাবে। এর জন্য অ্যাক্সেসিবিলিটি সেবা \"আমার সহকারী – স্ক্রিন লক টাইমার\" চালু করতে হবে।", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    PButton("অ্যাক্সেসিবিলিটি সেটিংস খুলুন", Modifier.fillMaxWidth(), Icons.Rounded.Settings, filled = false) {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("সময় শেষে ফোন লক করুন", Modifier.weight(1f))
                        Switch(lock, { lock = it; prefs.edit().putBoolean("lock", it).apply() })
                    }
                    if (Build.VERSION.SDK_INT >= 31)
                        PButton("সঠিক সময়ে অ্যালার্মের অনুমতি", Modifier.fillMaxWidth(), Icons.Rounded.Schedule, filled = false) {
                            ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                }
            }
        }
        item { SectionTitle("কেন্দ্রীয় সময়সূচি") }
        if (scheds.isEmpty()) item { Text("কোনো সময়সূচি নেই। লাইব্রেরিতে বইয়ের ⋮ মেনু থেকে সময় যোগ করুন।", fontSize = 13.sp, color = cs.onSurfaceVariant) }
        val sorted = scheds.sortedBy { it.hour * 60 + it.minute }
        items(count = sorted.size, key = { sorted[it].id }) { i ->
            val s = sorted[i]
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(timeLabel(s.hour, s.minute), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(books.find { it.id == s.bookId }?.title ?: "", fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Switch(s.enabled, { vm.toggleSched(s, it) })
                    IconButton({ vm.delSched(s) }) { Icon(Icons.Rounded.Delete, "মুছুন") }
                }
            }
        }
    }
}
