@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.sohokari

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun Messenger(vm: Vm, nav: (Long) -> Unit) {
    val books by vm.books.collectAsState()
    val last by vm.last.collectAsState()
    val lessons by vm.lessons.collectAsState()
    var q by remember { mutableStateOf("") }
    val fmt = remember { SimpleDateFormat("hh:mm a", Locale.forLanguageTag("bn")) }
    Column(Modifier.fillMaxSize()) {
        Text("মেসেঞ্জার", Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), singleLine = true,
            placeholder = { Text("সহকারী খুঁজুন…") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
            shape = RoundedCornerShape(26.dp))
        val shown = books.filter { q.isBlank() || it.title.contains(q, true) || it.assistantName.contains(q, true) }
        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("এখনো কোনো সহকারী নেই। \"লাইব্রেরি\" থেকে বই যোগ করুন।", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(shown, key = { it.id }) { b ->
                val lm = last.find { it.bookId == b.id }
                val unread = lessons.count { it.bookId == b.id && (it.status == 1 || it.status == 3) }
                Row(Modifier.fillMaxWidth().clickable { nav(b.id) }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    CoverImage(b, Modifier.size(54.dp), CircleShape, showTitle = false)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.assistantName, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(lm?.text?.take(70)?.replace("\n", " ") ?: "", fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(lm?.let { bn(fmt.format(Date(it.time))) } ?: "", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (unread > 0) {
                            Spacer(Modifier.height(4.dp))
                            Badge(containerColor = MaterialTheme.colorScheme.primary) { Text(bn(unread)) }
                        }
                    }
                }
                HorizontalDivider(Modifier.padding(start = 82.dp), color = MaterialTheme.colorScheme.outlineVariant)
            }
        }
    }
}

@Composable
fun Bubble(m: Msg, lesson: Lesson?, book: Book, onDone: () -> Unit, onLater: () -> Unit, onOpenBook: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val fmt = remember { SimpleDateFormat("hh:mm a", Locale.forLanguageTag("bn")) }
    val mine = m.fromUser
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = if (mine) RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp) else RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp),
            color = if (mine) cs.primary else cs.surfaceContainer,
            contentColor = if (mine) cs.onPrimary else cs.onSurface,
            border = if (mine) null else BorderStroke(1.dp, cs.outlineVariant),
            shadowElevation = 1.dp,
            modifier = if (mine) Modifier.widthIn(max = 300.dp) else Modifier.fillMaxWidth(0.94f)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val split = if (!mine && m.text.startsWith("📚")) {
                    val i = m.text.indexOf("\n\n")
                    if (i > 0) m.text.substring(0, i) to m.text.substring(i + 2) else null
                } else null
                val head: String? = split?.first
                val body: String = split?.second ?: m.text
                if (head != null) {
                    val lines = head.split("\n")
                    Text(lines.getOrElse(0) { "" }.removePrefix("📚 "), fontSize = 12.sp, color = cs.secondary, fontWeight = FontWeight.SemiBold)
                    Text(lines.getOrElse(1) { "" }.removePrefix("📖 "), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    HorizontalDivider(color = cs.outlineVariant)
                }
                SelectionContainer {
                    if (mine) Text(body, fontSize = 16.sp) else Text(readText(body), fontSize = 18.sp)
                }
                if (lesson != null) {
                    if (lesson.status == 2) {
                        Text("✅ পড়া সম্পন্ন", color = cs.primary, fontWeight = FontWeight.SemiBold)
                    } else {
                        PButton("পড়া সম্পন্ন করুন", Modifier.fillMaxWidth(), Icons.Rounded.CheckCircle) { onDone() }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PButton("পরে পড়ব", Modifier.weight(1f), Icons.Rounded.Schedule, filled = false) { onLater() }
                            if (book.pdfPath.isNotBlank() && lesson.pageFrom > 0)
                                PButton("মূল বই খুলুন", Modifier.weight(1f), Icons.Rounded.AutoStories, filled = false) { onOpenBook() }
                        }
                    }
                }
                Text(bn(fmt.format(Date(m.time))), fontSize = 11.sp, color = if (mine) cs.onPrimary.copy(alpha = 0.8f) else cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ChatScreen(vm: Vm, book: Book, back: () -> Unit, nav: (Screen) -> Unit) {
    BackHandler(onBack = back)
    val msgs by remember(book.id) { vm.msgs(book.id) }.collectAsState(emptyList())
    val lessons by vm.lessons.collectAsState()
    val st = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) st.animateScrollToItem(msgs.lastIndex) }
    Scaffold(topBar = {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CoverImage(book, Modifier.size(40.dp), CircleShape, showTitle = false)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(book.assistantName, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (book.pages > 0) "${bn(book.pages)} পৃষ্ঠার বই" else book.category, fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            },
            navigationIcon = { IconButton(back) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "পিছনে") } })
    }) { p ->
        Column(Modifier.padding(p).fillMaxSize()) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = st, contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(msgs, key = { it.id }) { m ->
                    val lesson = if (m.lessonId > 0) lessons.find { it.id == m.lessonId } else null
                    Bubble(m, lesson, book, { vm.markDone(m.lessonId) }, { vm.later(m.lessonId) }, {
                        nav(Screen.Reader(book.id, ((lesson?.pageFrom ?: 1) - 1).coerceAtLeast(0)))
                    })
                }
            }
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("বার্তা লিখুন…") },
                    maxLines = 3, shape = RoundedCornerShape(26.dp))
                Spacer(Modifier.width(8.dp))
                FilledIconButton({ if (input.isNotBlank()) { vm.userSay(book, input.trim()); input = "" } }, Modifier.size(52.dp)) {
                    Icon(Icons.AutoMirrored.Rounded.Send, "পাঠান")
                }
            }
        }
    }
}
