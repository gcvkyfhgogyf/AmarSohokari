package com.amar.sohokari

import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

object PdfUtil {
    fun render(r: PdfRenderer, index: Int, width: Int): Bitmap {
        val p = r.openPage(index)
        try {
            val h = (width.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
            val b = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            b.eraseColor(Color.WHITE)
            p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return b
        } finally { p.close() }
    }
}

/** পাঠকের জন্য মূল PDF-এর পৃষ্ঠা ছবি আকারে দেখায়। */
class PdfSession(file: File) {
    private val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    val count: Int = renderer.pageCount
    private val mutex = Mutex()
    private val cache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    suspend fun page(i: Int, width: Int): Bitmap = withContext(Dispatchers.Default) {
        val key = "$i-$width"
        val hit = cache.get(key)
        if (hit != null) hit
        else mutex.withLock {
            val again = cache.get(key)
            if (again != null) again
            else { val b = PdfUtil.render(renderer, i, width); cache.put(key, b); b }
        }
    }

    fun close() {
        try { renderer.close() } catch (e: Exception) { }
        try { pfd.close() } catch (e: Exception) { }
    }
}

object Content {
    private val noise = Regex("(?im)^\\s*page\\s*\\d+\\s*(of|/)\\s*\\d+\\s*$")
    fun clean(t: String): String = t.replace(noise, "").replace(Regex("\\n{3,}"), "\n\n").trim()

    fun buildText(pages: List<PageText>, from: Int, to: Int): String {
        val m = pages.associateBy { it.page }
        return (from..to).joinToString("\n\n") { p ->
            val t = m[p]?.text?.trim().orEmpty()
            "— পৃষ্ঠা ${bn(p)} —\n" + t.ifBlank { "(এই পৃষ্ঠায় কোনো লেখা শনাক্ত হয়নি)" }
        }
    }

    /** পাঠের সম্পূর্ণ লেখা। প্রস্তুত না থাকলে ওই পৃষ্ঠাগুলো এখনই OCR করে। */
    suspend fun lessonText(ctx: Context, book: Book, l: Lesson): String {
        if (l.text.isNotBlank()) return l.text
        if (l.pageFrom <= 0 || book.pdfPath.isBlank()) return ""
        val dao = AppDb.get(ctx).dao()
        val have = dao.pageRange(book.id, l.pageFrom, l.pageTo).map { it.page }.toSet()
        val missing = (l.pageFrom..l.pageTo).filter { it !in have }
        if (missing.isNotEmpty()) Ocr.ocrPages(ctx, book, missing)
        val text = buildText(dao.pageRange(book.id, l.pageFrom, l.pageTo), l.pageFrom, l.pageTo)
        dao.setLessonText(l.id, text)
        return text
    }

    /** বড় লেখা কোনো অংশ বাদ না দিয়ে ধারাবাহিক অংশে ভাগ করে। */
    fun chunk(text: String, max: Int = 2800): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) { out.add(cur.toString().trim()); cur.clear() } }
        for (para in text.split("\n\n")) {
            var rest = para
            while (rest.length > max) {
                var cut = rest.lastIndexOf('\n', max)
                if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
                if (cut < max / 2) cut = max
                flush()
                out.add(rest.substring(0, cut).trim())
                rest = rest.substring(cut).trim()
            }
            if (cur.length + rest.length + 2 > max) flush()
            if (rest.isNotEmpty()) { if (cur.isNotEmpty()) cur.append("\n\n"); cur.append(rest) }
        }
        flush()
        return out
    }
}

object Ocr {
    private val lock = Mutex()
    fun lang(cat: String) = if (cat == "কুরআন" || cat == "হাদিস") "ben+ara+eng" else "ben+eng"

    private fun prepare(ctx: Context): File {
        val root = File(ctx.filesDir, "tess")
        val dir = File(root, "tessdata")
        dir.mkdirs()
        for (n in listOf("ben", "eng", "ara")) {
            val f = File(dir, "$n.traineddata")
            if (!f.exists() || f.length() == 0L)
                ctx.assets.open("tessdata/$n.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
        return root
    }

    suspend fun ocrPages(ctx: Context, book: Book, pages: List<Int>, onPage: suspend (Int) -> Unit = {}) =
        withContext(Dispatchers.Default) {
            lock.withLock {
                val dao = AppDb.get(ctx).dao()
                val tess = TessBaseAPI()
                try {
                    if (tess.init(prepare(ctx).absolutePath, lang(book.category))) {
                        val pfd = ParcelFileDescriptor.open(File(book.pdfPath), ParcelFileDescriptor.MODE_READ_ONLY)
                        val r = PdfRenderer(pfd)
                        try {
                            pages.forEachIndexed { i, p ->
                                val bmp = PdfUtil.render(r, p - 1, 1800)
                                tess.setImage(bmp)
                                val t = Content.clean(tess.getUTF8Text() ?: "")
                                bmp.recycle()
                                dao.insertPage(PageText(book.id, p, t, true))
                                onPage(i + 1)
                            }
                        } finally { r.close(); pfd.close() }
                    }
                } finally { tess.recycle() }
                Unit
            }
        }

    suspend fun materialize(ctx: Context, bookId: Long) {
        val dao = AppDb.get(ctx).dao()
        for (l in dao.lessonsOfBook(bookId)) {
            if (l.text.isNotBlank() || l.pageFrom <= 0) continue
            val ps = dao.pageRange(bookId, l.pageFrom, l.pageTo)
            if (ps.size == l.pageTo - l.pageFrom + 1) dao.setLessonText(l.id, Content.buildText(ps, l.pageFrom, l.pageTo))
        }
    }

    suspend fun runBook(ctx: Context, bookId: Long, onProgress: (Int, Int) -> Unit) {
        val dao = AppDb.get(ctx).dao()
        val book = dao.book(bookId) ?: return
        val have = dao.pageNumbers(bookId).toSet()
        val missing = (1..book.pages).filter { it !in have }
        dao.setOcr(bookId, 0, missing.size)
        if (missing.isNotEmpty()) {
            ocrPages(ctx, book, missing) { n -> dao.setOcr(bookId, n, missing.size); onProgress(n, missing.size) }
        }
        materialize(ctx, bookId)
        dao.setOcr(bookId, missing.size, missing.size)
    }
}

class OcrService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    override fun onBind(intent: Intent?): IBinder? = null

    private fun notif(text: String, done: Int, total: Int): Notification {
        Notifier.channel(this)
        return NotificationCompat.Builder(this, Notifier.CH).setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("বই থেকে লেখা শনাক্ত (OCR) চলছে").setContentText(text)
            .setProgress(total, done, total == 0).setOngoing(true).setOnlyAlertOnce(true).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val bookId = intent?.getLongExtra("bookId", 0L) ?: 0L
        ServiceCompat.startForeground(this, 4242, notif("শুরু হচ্ছে…", 0, 0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        scope.launch {
            try {
                Ocr.runBook(this@OcrService, bookId) { d, t ->
                    try {
                        NotificationManagerCompat.from(this@OcrService).notify(4242, notif("পৃষ্ঠা ${bn(d)} / ${bn(t)}", d, t))
                    } catch (e: SecurityException) { }
                }
            } catch (e: Throwable) {
            } finally { stopSelf(startId) }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
