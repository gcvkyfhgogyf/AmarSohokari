package com.amar.sohokari

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity
data class Book(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val author: String = "", val category: String = "সাধারণ বই",
    val assistantName: String, val createdAt: Long = System.currentTimeMillis(),
    val pdfPath: String = "", val coverPath: String = "", val pages: Int = 0,
    val lastPage: Int = 0, val ocrDone: Int = 0, val ocrTotal: Int = 0
)

// status: 0 = পাঠানো হয়নি, 1 = পাঠানো হয়েছে (অসম্পূর্ণ), 2 = সম্পন্ন, 3 = পরে পড়ব
@Entity(indices = [Index("bookId")])
data class Lesson(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long, val idx: Int, val title: String, val text: String,
    val status: Int = 0, val sentAt: Long = 0, val doneAt: Long = 0,
    val pageFrom: Int = 0, val pageTo: Int = 0
)

@Entity(indices = [Index("bookId")])
data class Msg(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long, val fromUser: Boolean, val text: String,
    val lessonId: Long = 0, val time: Long = System.currentTimeMillis()
)

@Entity
data class Sched(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long, val hour: Int, val minute: Int, val enabled: Boolean = true
)

@Entity(primaryKeys = ["bookId", "page"])
data class PageText(val bookId: Long, val page: Int, val text: String, val ocr: Boolean)

@Dao
interface AppDao {
    @Insert suspend fun insertBook(b: Book): Long
    @Insert suspend fun insertLessons(l: List<Lesson>)
    @Insert suspend fun insertMsg(m: Msg): Long
    @Insert suspend fun insertSched(s: Sched): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertPage(p: PageText)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertPages(p: List<PageText>)
    @Query("SELECT * FROM Book ORDER BY id DESC") fun books(): Flow<List<Book>>
    @Query("SELECT * FROM Lesson") fun lessons(): Flow<List<Lesson>>
    @Query("SELECT * FROM Msg WHERE bookId=:b ORDER BY id") fun msgs(b: Long): Flow<List<Msg>>
    @Query("SELECT * FROM Msg WHERE id IN (SELECT MAX(id) FROM Msg GROUP BY bookId)") fun lastMsgs(): Flow<List<Msg>>
    @Query("SELECT * FROM Sched") fun scheds(): Flow<List<Sched>>
    @Query("SELECT * FROM Sched") suspend fun schedsNow(): List<Sched>
    @Query("SELECT * FROM Sched WHERE bookId=:b") suspend fun schedsOfBook(b: Long): List<Sched>
    @Query("SELECT * FROM Sched WHERE id=:id") suspend fun sched(id: Long): Sched?
    @Query("SELECT * FROM Book WHERE id=:id") suspend fun book(id: Long): Book?
    @Query("SELECT * FROM Lesson WHERE id=:id") suspend fun lesson(id: Long): Lesson?
    @Query("SELECT * FROM Lesson WHERE bookId=:b ORDER BY idx") suspend fun lessonsOfBook(b: Long): List<Lesson>
    @Query("SELECT * FROM Lesson WHERE bookId=:b AND status=0 ORDER BY idx LIMIT 1") suspend fun nextLesson(b: Long): Lesson?
    @Query("UPDATE Lesson SET status=1, sentAt=:t WHERE id=:id") suspend fun markSent(id: Long, t: Long)
    @Query("UPDATE Lesson SET status=:s, doneAt=:t WHERE id=:id") suspend fun setStatus(id: Long, s: Int, t: Long)
    @Query("UPDATE Lesson SET text=:t WHERE id=:id") suspend fun setLessonText(id: Long, t: String)
    @Query("SELECT * FROM PageText WHERE bookId=:b AND page BETWEEN :f AND :t ORDER BY page") suspend fun pageRange(b: Long, f: Int, t: Int): List<PageText>
    @Query("SELECT page FROM PageText WHERE bookId=:b") suspend fun pageNumbers(b: Long): List<Int>
    @Query("UPDATE Book SET ocrDone=:d, ocrTotal=:t WHERE id=:id") suspend fun setOcr(id: Long, d: Int, t: Int)
    @Query("UPDATE Book SET lastPage=:p WHERE id=:id") suspend fun setLastPage(id: Long, p: Int)
    @Query("UPDATE Book SET title=:t, author=:a WHERE id=:id") suspend fun updateBookInfo(id: Long, t: String, a: String)
    @Query("UPDATE Book SET pdfPath=:p, coverPath=:c, pages=:n WHERE id=:id") suspend fun setBookFiles(id: Long, p: String, c: String, n: Int)
    @Query("UPDATE Sched SET enabled=:e WHERE id=:id") suspend fun setSched(id: Long, e: Boolean)
    @Query("DELETE FROM Sched WHERE id=:id") suspend fun delSched(id: Long)
    @Query("DELETE FROM Book WHERE id=:id") suspend fun delBook(id: Long)
    @Query("DELETE FROM Lesson WHERE bookId=:id") suspend fun delLessons(id: Long)
    @Query("DELETE FROM Msg WHERE bookId=:id") suspend fun delMsgs(id: Long)
    @Query("DELETE FROM Sched WHERE bookId=:id") suspend fun delScheds(id: Long)
    @Query("DELETE FROM PageText WHERE bookId=:id") suspend fun delPages(id: Long)
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE Book ADD COLUMN pdfPath TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE Book ADD COLUMN coverPath TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE Book ADD COLUMN pages INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE Book ADD COLUMN lastPage INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE Book ADD COLUMN ocrDone INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE Book ADD COLUMN ocrTotal INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE Lesson ADD COLUMN pageFrom INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE Lesson ADD COLUMN pageTo INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE TABLE IF NOT EXISTS PageText (bookId INTEGER NOT NULL, page INTEGER NOT NULL, text TEXT NOT NULL, ocr INTEGER NOT NULL, PRIMARY KEY(bookId, page))")
    }
}

@Database(entities = [Book::class, Lesson::class, Msg::class, Sched::class, PageText::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "app.db")
                .addMigrations(MIGRATION_1_2).build().also { inst = it }
        }
    }
}
