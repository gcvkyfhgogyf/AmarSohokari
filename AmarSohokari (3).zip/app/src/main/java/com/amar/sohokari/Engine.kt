package com.amar.sohokari

import android.app.*
import android.content.*
import android.media.AudioManager
import android.os.Build
import android.view.KeyEvent
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.*
import java.util.Calendar

object Notifier {
    const val CH = "reading"
    fun channel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26)
            c.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CH, "পড়ার বার্তা", NotificationManager.IMPORTANCE_HIGH))
    }
    fun show(c: Context, title: String, body: String, bookId: Long, id: Int) {
        channel(c)
        val i = Intent(c, MainActivity::class.java).putExtra("bookId", bookId)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(c, bookId.toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CH).setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title).setContentText(body.take(100).replace("\n", " "))
            .setStyle(NotificationCompat.BigTextStyle().bigText(body.take(1500)))
            .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { NotificationManagerCompat.from(c).notify(id, n) } catch (e: SecurityException) { }
    }
}

object Sender {
    /** পরবর্তী পাঠের সম্পূর্ণ লেখা চ্যাটে বার্তা হিসেবে যোগ করে; বড় হলে ধারাবাহিক অংশে ভাগ করে। */
    suspend fun deliver(c: Context, bookId: Long, notify: Boolean = true) {
        val dao = AppDb.get(c).dao()
        val book = dao.book(bookId) ?: return
        val l = dao.nextLesson(bookId)
        if (l == null) {
            dao.insertMsg(Msg(bookId = bookId, fromUser = false, text = "🎉 এই বইয়ের সব পাঠ পাঠানো হয়ে গেছে। অভিনন্দন!"))
            return
        }
        dao.markSent(l.id, System.currentTimeMillis())
        val body = Content.lessonText(c, book, l)
        val head = "📚 ${book.title}\n📖 ${l.title}"
        val parts = if (body.isBlank()) listOf("⚠️ এই পাঠের লেখা শনাক্ত করা যায়নি। নিচের \"মূল বই খুলুন\" বাটনে চাপ দিয়ে মূল পৃষ্ঠা পড়ুন।")
        else Content.chunk(body)
        val n = parts.size
        parts.forEachIndexed { i, p ->
            val sb = StringBuilder()
            if (i == 0) sb.append(head).append("\n\n")
            if (n > 1) sb.append("(অংশ ${bn(i + 1)}/${bn(n)})\n")
            sb.append(p)
            dao.insertMsg(Msg(bookId = bookId, fromUser = false, text = sb.toString(), lessonId = if (i == n - 1) l.id else 0))
        }
        if (notify) Notifier.show(c, book.assistantName, "${l.title}\n$body".take(1500), bookId, l.id.toInt())
    }
}

object Scheduler {
    const val YT_CODE = 999999
    fun nextTrigger(h: Int, m: Int): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }.timeInMillis

    private fun pi(c: Context, code: Int, i: Intent) =
        PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun setAlarm(c: Context, code: Int, at: Long, i: Intent) {
        val am = c.getSystemService(AlarmManager::class.java)
        val p = pi(c, code, i)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
    }
    fun cancel(c: Context, code: Int) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, code, Intent(c, AlarmReceiver::class.java)))
    }
    fun schedule(c: Context, s: Sched) =
        setAlarm(c, s.id.toInt(), nextTrigger(s.hour, s.minute),
            Intent(c, AlarmReceiver::class.java).putExtra("type", "sched").putExtra("schedId", s.id))
    fun cancelSched(c: Context, s: Sched) = cancel(c, s.id.toInt())
}

/** স্ক্রিন লক টাইমার (আগের "ইউটিউব টাইমার")। কাজের পদ্ধতি অপরিবর্তিত। */
object LockTimer {
    fun start(c: Context, minutes: Int) {
        val end = System.currentTimeMillis() + minutes * 60_000L
        c.getSharedPreferences("p", 0).edit().putLong("yt_end", end).apply()
        Scheduler.setAlarm(c, Scheduler.YT_CODE, end, Intent(c, AlarmReceiver::class.java).putExtra("type", "yt"))
    }
    fun cancel(c: Context) {
        c.getSharedPreferences("p", 0).edit().remove("yt_end").apply()
        Scheduler.cancel(c, Scheduler.YT_CODE)
    }
    fun stop(c: Context) {
        val prefs = c.getSharedPreferences("p", 0)
        prefs.edit().remove("yt_end").apply()
        val am = c.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))
        val svc = StopService.instance
        if (svc != null) {
            svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            if (prefs.getBoolean("lock", false) && Build.VERSION.SDK_INT >= 28)
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        }
        val extra = if (svc == null) "\n(সেটিংসে অ্যাক্সেসিবিলিটি সেবা চালু করলে অ্যাপ থেকে বের হওয়া ও স্ক্রিন লক কাজ করবে)" else ""
        Notifier.show(c, "স্ক্রিন লক টাইমার শেষ", "সময় শেষ হয়েছে।$extra", 0, 777)
    }
}

class StopService : AccessibilityService() {
    companion object { var instance: StopService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDb.get(c).dao()
                when (i.getStringExtra("type")) {
                    "yt" -> LockTimer.stop(c)
                    "later" -> {
                        val l = dao.lesson(i.getLongExtra("lessonId", 0))
                        val b = l?.let { dao.book(it.bookId) }
                        if (l != null && b != null && l.status != 2)
                            Notifier.show(c, b.assistantName, "⏰ মনে করিয়ে দিচ্ছি: ${l.title}", b.id, l.id.toInt())
                    }
                    else -> {
                        val s = dao.sched(i.getLongExtra("schedId", 0))
                        if (s != null && s.enabled) { Sender.deliver(c, s.bookId); Scheduler.schedule(c, s) }
                    }
                }
            } finally { pending.finish() }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppDb.get(c).dao().schedsNow().filter { it.enabled }.forEach { Scheduler.schedule(c, it) }
                val end = c.getSharedPreferences("p", 0).getLong("yt_end", 0)
                if (end > System.currentTimeMillis())
                    Scheduler.setAlarm(c, Scheduler.YT_CODE, end, Intent(c, AlarmReceiver::class.java).putExtra("type", "yt"))
            } finally { pending.finish() }
        }
    }
}
