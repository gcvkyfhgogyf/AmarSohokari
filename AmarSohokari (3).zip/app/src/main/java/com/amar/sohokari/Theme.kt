package com.amar.sohokari

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Navy = Color(0xFF172B4D)
val Emerald = Color(0xFF16866A)
val Gold = Color(0xFFC6A66B)

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF34B895), onPrimary = Color(0xFF04231A),
        primaryContainer = Color(0xFF1C3B4A), onPrimaryContainer = Color(0xFFDCEFE9),
        secondary = Gold, onSecondary = Color(0xFF2A2110), tertiary = Color(0xFF8FA8D6),
        background = Color(0xFF0D1424), onBackground = Color(0xFFE8ECF4),
        surface = Color(0xFF0D1424), onSurface = Color(0xFFE8ECF4),
        surfaceVariant = Color(0xFF1B2640), onSurfaceVariant = Color(0xFFA9B3C7),
        surfaceContainer = Color(0xFF162033), surfaceContainerHigh = Color(0xFF1B2740),
        outline = Color(0xFF3A4864), outlineVariant = Color(0xFF273450)
    ) else lightColorScheme(
        primary = Emerald, onPrimary = Color.White,
        primaryContainer = Color(0xFFDDF1EA), onPrimaryContainer = Navy,
        secondary = Gold, onSecondary = Color.White, tertiary = Navy,
        background = Color(0xFFF7F8FA), onBackground = Color(0xFF202735),
        surface = Color(0xFFF7F8FA), onSurface = Color(0xFF202735),
        surfaceVariant = Color(0xFFE9EDF3), onSurfaceVariant = Color(0xFF5B6577),
        surfaceContainer = Color.White, surfaceContainerHigh = Color(0xFFEFF2F6),
        outline = Color(0xFFC3CAD6), outlineVariant = Color(0xFFE2E6ED)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
