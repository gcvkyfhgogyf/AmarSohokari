package com.amar.sohokari

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class Vm(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    private val dao = AppDb.get(app).dao()
    val books = dao.books().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val lessons = dao.lessons().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val scheds = dao.scheds().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val last = dao.lastMsgs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun msgs(b: Long) = dao.msgs(b)

    fun rescheduleAll() = viewModelScope.launch(Dispatchers.IO) {
        dao.schedsNow().filter { it.enabled }.forEach { Scheduler.schedule(ctx, it) }
    }

    private fun startOcr(bookId: Long) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, OcrService::class.java).putExtra("bookId", bookId))
    }

    /** পুরোনো (OCR ছাড়া) বইয়ের জন্য নয়; PDF-এর মূল ফাইল সংরক্ষিত থাকলে আবার OCR চালায়। */
    fun reOcr(b: Book) = viewModelScope.launch(Dispatchers.IO) {
        if (b.pdfPath.isNotBlank()) startOcr(b.id)
    }

    private suspend fun importPdf(uri: Uri, title: String, author: String, cat: String, n: Int, forceOcr: Boolean, fname: String): String? {
        val tmp = File(ctx.cacheDir, "import.pdf")
        val opened = ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        if (opened == null) return "ফাইল পড়া যায়নি"
        var pages = 0
        var coverBmp: Bitmap? = null
        val pfd = ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            pages = r.pageCount
            if (pages > 0) coverBmp = PdfUtil.render(r, 0, 480)
        } finally { r.close(); pfd.close() }
        if (pages == 0) return "PDF-এ কোনো পৃষ্ঠা নেই"

        val texts = mutableMapOf<Int, String>()
        if (!forceOcr) {
            try {
                PDFBoxResourceLoader.init(ctx)
                val doc = PDDocument.load(tmp)
                try {
                    val ts = PDFTextStripper()
                    for (p in 1..pages) {
                        ts.startPage = p; ts.endPage = p
                        val t = Content.clean(ts.getText(doc))
                        if (t.length >= 40) texts[p] = t
                    }
                } finally { doc.close() }
            } catch (e: Throwable) { texts.clear() }
        }

        val name = title.ifBlank { fname.substringBeforeLast('.') }
        val id = dao.insertBook(Book(title = name, author = author, category = cat, assistantName = "$cat সহকারী: $name", pages = pages))
        val dir = File(ctx.filesDir, "books").apply { mkdirs() }
        val pdf = File(dir, "$id.pdf")
        tmp.copyTo(pdf, overwrite = true)
        tmp.delete()
        var cover = ""
        coverBmp?.let { b ->
            val f = File(dir, "$id.jpg")
            f.outputStream().use { o -> b.compress(Bitmap.CompressFormat.JPEG, 85, o) }
            cover = f.absolutePath
        }
        dao.setBookFiles(id, pdf.absolutePath, cover, pages)
        val pt = texts.map { PageText(id, it.key, it.value, false) }
        dao.insertPages(pt)
        val k = n.coerceAtLeast(1)
        val lessons = (1..pages).chunked(k).mapIndexed { i, g ->
            val f = g.first(); val t = g.last()
            val ready = g.all { it in texts }
            Lesson(bookId = id, idx = i,
                title = if (f == t) "পৃষ্ঠা ${bn(f)}" else "পৃষ্ঠা ${bn(f)}–${bn(t)}",
                text = if (ready) Content.buildText(pt, f, t) else "", pageFrom = f, pageTo = t)
        }
        dao.insertLessons(lessons)
        val missing = pages - texts.size
        val note = if (missing > 0) " ${bn(missing)}টি পৃষ্ঠা স্ক্যান করা ছবি, তাই OCR চলছে (নোটিফিকেশনে অগ্রগতি দেখা যাবে)। শেষ হলে পুরো লেখা মেসেজে আসবে।" else ""
        dao.insertMsg(Msg(bookId = id, fromUser = false,
            text = "আসসালামু আলাইকুম! আমি \"$name\" বইয়ের সহকারী। মোট ${bn(pages)}টি পৃষ্ঠা, ${bn(lessons.size)}টি পাঠ।$note\nসময়সূচি ঠিক করলে নির্ধারিত সময়ে পাঠ এখানেই চলে আসবে। এখনই শুরু করতে \"পরবর্তী\" লিখুন।"))
        if (missing > 0) startOcr(id)
        return null
    }

    fun importBook(uri: Uri?, pasted: String, title: String, author: String, cat: String,
                   mode: Int, n: Int, forceOcr: Boolean, done: (String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                var fname = "লেখা.txt"
                if (uri != null) fname = Importer.name(ctx, uri)
                if (uri != null && fname.lowercase().endsWith(".pdf")) {
                    val err = importPdf(uri, title, author, cat, n, forceOcr, fname)
                    withContext(Dispatchers.Main) { done(err) }
                    return@launch
                }
                val units = if (uri != null) Importer.units(ctx, uri, fname) else Importer.paras(pasted)
                if (units.all { it.isBlank() }) {
                    withContext(Dispatchers.Main) { done("কোনো লেখা পাওয়া যায়নি।") }
                    return@launch
                }
                val parts = when (mode) {
                    0 -> Splitter.byCount(units, n, "অনুচ্ছেদ")
                    1 -> Splitter.byWords(units, n)
                    else -> Splitter.numbered(units.joinToString("\n"), n).ifEmpty { Splitter.byCount(units, n, "অংশ") }
                }
                val name = title.ifBlank { fname.substringBeforeLast('.') }
                val id = dao.insertBook(Book(title = name, author = author, category = cat, assistantName = "$cat সহকারী: $name"))
                dao.insertLessons(parts.mapIndexed { i, p -> Lesson(bookId = id, idx = i, title = p.first, text = p.second) })
                dao.insertMsg(Msg(bookId = id, fromUser = false,
                    text = "আসসালামু আলাইকুম! আমি \"$name\" বইয়ের সহকারী। মোট ${bn(parts.size)}টি পাঠ তৈরি হয়েছে। সময়সূচি ঠিক করলে নির্ধারিত সময়ে পাঠ এখানেই চলে আসবে। এখনই শুরু করতে \"পরবর্তী\" লিখুন।"))
                withContext(Dispatchers.Main) { done(null) }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { done("ত্রুটি: ${e.message}") }
            }
        }
    }

    fun addSched(bookId: Long, h: Int, m: Int) = viewModelScope.launch(Dispatchers.IO) {
        val s = Sched(bookId = bookId, hour = h, minute = m)
        Scheduler.schedule(ctx, s.copy(id = dao.insertSched(s)))
    }
    fun toggleSched(s: Sched, e: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        dao.setSched(s.id, e)
        if (e) Scheduler.schedule(ctx, s) else Scheduler.cancelSched(ctx, s)
    }
    fun delSched(s: Sched) = viewModelScope.launch(Dispatchers.IO) {
        Scheduler.cancelSched(ctx, s); dao.delSched(s.id)
    }
    fun delBook(b: Book) = viewModelScope.launch(Dispatchers.IO) {
        dao.schedsOfBook(b.id).forEach { Scheduler.cancelSched(ctx, it) }
        dao.delScheds(b.id); dao.delMsgs(b.id); dao.delLessons(b.id); dao.delPages(b.id); dao.delBook(b.id)
        if (b.pdfPath.isNotBlank()) File(b.pdfPath).delete()
        if (b.coverPath.isNotBlank()) File(b.coverPath).delete()
    }
    fun updateBook(b: Book, title: String, author: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.updateBookInfo(b.id, title.ifBlank { b.title }, author)
    }
    fun saveLastPage(bookId: Long, page: Int) = viewModelScope.launch(Dispatchers.IO) { dao.setLastPage(bookId, page) }
    fun sendNow(bookId: Long) = viewModelScope.launch(Dispatchers.IO) { Sender.deliver(ctx, bookId, notify = false) }

    fun markDone(lessonId: Long) = viewModelScope.launch(Dispatchers.IO) {
        dao.setStatus(lessonId, 2, System.currentTimeMillis())
    }
    fun later(lessonId: Long) = viewModelScope.launch(Dispatchers.IO) {
        dao.setStatus(lessonId, 3, 0)
        Scheduler.setAlarm(ctx, (2_000_000 + lessonId).toInt(), System.currentTimeMillis() + 3_600_000L,
            Intent(ctx, AlarmReceiver::class.java).putExtra("type", "later").putExtra("lessonId", lessonId))
    }
    fun userSay(book: Book, text: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.insertMsg(Msg(bookId = book.id, fromUser = true, text = text))
        if (text.contains("পরবর্তী") || text.contains("next", true)) Sender.deliver(ctx, book.id, notify = false)
        else dao.insertMsg(Msg(bookId = book.id, fromUser = false,
            text = "এখন আমি অফলাইনে চলছি। \"পরবর্তী\" লিখলে সঙ্গে সঙ্গে পরবর্তী পাঠ পাঠাব। AI-ভিত্তিক প্রশ্নোত্তর ও পরামর্শ পরের ধাপে যুক্ত হবে।"))
    }
}
