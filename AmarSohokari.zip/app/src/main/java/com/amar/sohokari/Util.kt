package com.amar.sohokari

import java.util.Calendar

fun bn(s: String): String = s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")
fun bn(n: Int): String = bn(n.toString())

fun timeLabel(h: Int, m: Int): String {
    val p = when { h < 5 -> "রাত"; h < 12 -> "সকাল"; h < 16 -> "দুপুর"; h < 18 -> "বিকেল"; else -> "রাত" }
    val hh = if (h % 12 == 0) 12 else h % 12
    return "$p ${bn(hh)}:${bn(m.toString().padStart(2, '0'))}"
}

fun startOfDay(t: Long): Long = Calendar.getInstance().apply {
    timeInMillis = t; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun prevDay(t: Long): Long = Calendar.getInstance().apply { timeInMillis = t; add(Calendar.DAY_OF_YEAR, -1) }.timeInMillis

fun streak(l: List<Lesson>, now: Long): Int {
    val days = l.filter { it.status == 2 }.map { startOfDay(it.doneAt) }.toSet()
    var d = startOfDay(now)
    if (d !in days) d = startOfDay(prevDay(d))
    var c = 0
    while (d in days) { c++; d = startOfDay(prevDay(d)) }
    return c
}
