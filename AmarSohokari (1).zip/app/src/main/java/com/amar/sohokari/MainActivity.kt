@file:OptIn(ExperimentalMaterial3Api::class)

package com.amar.sohokari

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: Vm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.channel(this)
        val openBook = intent.getLongExtra("bookId", -1)
        val prefs = getSharedPreferences("p", 0)
        setContent {
            var theme by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            AppTheme(theme) { App(vm, openBook, theme) { theme = it; prefs.edit().putInt("theme", it).apply() } }
        }
    }
}

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Color(0xFF5CC8B8), secondary = Color(0xFFE0B656))
        else lightColorScheme(primary = Color(0xFF0B6B5D), secondary = Color(0xFF9A7B1F)),
        content = content
    )
}

@Composable
fun App(vm: Vm, openBook: Long, theme: Int, setTheme: (Int) -> Unit) {
    var tab by remember { mutableIntStateOf(if (openBook > 0) 1 else 0) }
    var chatId by remember { mutableLongStateOf(openBook) }
    val books by vm.books.collectAsState()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        vm.rescheduleAll()
    }
    val chatBook = books.find { it.id == chatId }
    if (chatBook != null && tab == 1) { ChatScreen(vm, chatBook) { chatId = -1 }; return }
    val items = listOf("🏠" to "হোম", "💬" to "মেসেঞ্জার", "📚" to "লাইব্রেরি", "📈" to "অগ্রগতি", "⚙️" to "সেটিংস")
    Scaffold(bottomBar = {
        NavigationBar {
            items.forEachIndexed { i, (ic, l) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i; chatId = -1 }, icon = { Text(ic) }, label = { Text(l) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Home(vm)
                1 -> Messenger(vm) { chatId = it }
                2 -> Library(vm)
                3 -> ProgressScreen(vm)
                else -> SettingsScreen(vm, theme, setTheme)
            }
        }
    }
}

@Composable
fun Stat(label: String, value: String, mod: Modifier = Modifier) {
    Card(mod) {
        Column(Modifier.padding(14.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
            Text(label, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun Home(vm: Vm) {
    val ctx = LocalContext.current
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val scheds by vm.scheds.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val ytEnd = prefs.getLong("yt_end", 0)
    val day0 = startOfDay(now)
    val sentToday = lessons.count { it.sentAt >= day0 }
    val doneToday = lessons.count { it.status == 2 && it.doneAt >= day0 }
    val incomplete = lessons.count { it.status == 1 || it.status == 3 }
    val nextS = scheds.filter { it.enabled }.minByOrNull { Scheduler.nextTrigger(it.hour, it.minute) }
    val nextBook = books.find { it.id == nextS?.bookId }
    val fmt = remember { SimpleDateFormat("EEEE, d MMMM yyyy", Locale.forLanguageTag("bn")) }
    var dlg by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("আমার সহকারী", fontSize = 26.sp, color = MaterialTheme.colorScheme.primary)
        Text(bn(fmt.format(Date(now))), fontSize = 15.sp)
        Text(bn(SimpleDateFormat("hh:mm:ss a", Locale.forLanguageTag("bn")).format(Date(now))), fontSize = 30.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("আজকের মোট পড়া", bn(sentToday), Modifier.weight(1f))
            Stat("সম্পন্ন", bn(doneToday), Modifier.weight(1f))
            Stat("অসম্পূর্ণ", bn(incomplete), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("মোট বই", bn(books.size), Modifier.weight(1f))
            Stat("ধারাবাহিক দিন", bn(streak(lessons, now)), Modifier.weight(1f))
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("আজকের অগ্রগতি")
                val f = if (sentToday == 0) 0f else (doneToday.toFloat() / sentToday).coerceIn(0f, 1f)
                LinearProgressIndicator(progress = { f }, modifier = Modifier.fillMaxWidth())
                Text("পরবর্তী পড়ার সময়: " + (nextS?.let { timeLabel(it.hour, it.minute) } ?: "ঠিক করা নেই"))
                Text("পরবর্তী বিষয়: " + (nextBook?.title ?: "—"))
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("▶️ ইউটিউব টাইমার", fontSize = 18.sp)
                if (ytEnd > now) {
                    val rem = (ytEnd - now) / 1000
                    Text("চলছে: ${bn(rem / 60)} মিনিট ${bn(rem % 60)} সেকেন্ড বাকি")
                    OutlinedButton({ YtTimer.cancel(ctx) }) { Text("টাইমার বাতিল") }
                } else {
                    Text("বন্ধ আছে")
                    Button({ dlg = true }) { Text("টাইমার চালু করুন") }
                }
            }
        }
    }
    if (dlg) {
        val opts = listOf("৫ মিনিট" to 5, "১০ মিনিট" to 10, "১৫ মিনিট" to 15, "২০ মিনিট" to 20, "৩০ মিনিট" to 30,
            "৪৫ মিনিট" to 45, "১ ঘণ্টা" to 60, "১ ঘণ্টা ৩০ মিনিট" to 90)
        var custom by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { dlg = false }, confirmButton = { TextButton({ dlg = false }) { Text("বন্ধ") } },
            title = { Text("সময় বেছে নিন") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    opts.forEach { (l, m) -> TextButton({ YtTimer.start(ctx, m); dlg = false }) { Text(l) } }
                    OutlinedTextField(custom, { custom = it.filter { c -> c.isDigit() } }, label = { Text("কাস্টম (মিনিট)") }, singleLine = true)
                    TextButton({ custom.toIntOrNull()?.takeIf { it > 0 }?.let { YtTimer.start(ctx, it); dlg = false } }) { Text("কাস্টম সময় চালু করুন") }
                }
            })
    }
}

@Composable
fun Messenger(vm: Vm, open: (Long) -> Unit) {
    val books by vm.books.collectAsState()
    val last by vm.last.collectAsState()
    val lessons by vm.lessons.collectAsState()
    if (books.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("এখনো কোনো সহকারী নেই। \"লাইব্রেরি\" থেকে বই যোগ করুন।", textAlign = TextAlign.Center)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(books, key = { it.id }) { b ->
            val lm = last.find { it.bookId == b.id }
            val unread = lessons.count { it.bookId == b.id && (it.status == 1 || it.status == 3) }
            ListItem(
                leadingContent = { Text("💬", fontSize = 26.sp) },
                headlineContent = { Text(b.assistantName, maxLines = 1) },
                supportingContent = { Text(lm?.text?.take(70)?.replace("\n", " ") ?: "", maxLines = 1) },
                trailingContent = { if (unread > 0) Badge { Text(bn(unread)) } },
                modifier = Modifier.clickable { open(b.id) })
            HorizontalDivider()
        }
    }
}

@Composable
fun Bubble(m: Msg, status: Int?, onDone: () -> Unit, onLater: () -> Unit) {
    var exp by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Surface(shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 340.dp),
            color = if (m.fromUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val long = m.text.length > 700
                SelectionContainer { Text(if (long && !exp) m.text.take(700) + "…" else m.text, fontSize = 17.sp, lineHeight = 26.sp) }
                if (long) TextButton({ exp = !exp }) { Text(if (exp) "সংক্ষেপ করুন" else "সম্পূর্ণ পড়া খুলুন") }
                if (status != null) {
                    if (status == 2) Text("✅ পড়া সম্পন্ন", color = MaterialTheme.colorScheme.primary)
                    else {
                        Button(onDone, Modifier.fillMaxWidth()) { Text("পড়া সম্পন্ন করুন") }
                        OutlinedButton(onLater, Modifier.fillMaxWidth()) { Text(if (status == 3) "আবার পরে পড়ব (১ ঘণ্টা)" else "পরে পড়ব (১ ঘণ্টা পর মনে করাও)") }
                    }
                }
                Text(bn(SimpleDateFormat("hh:mm a", Locale.forLanguageTag("bn")).format(Date(m.time))), fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ChatScreen(vm: Vm, book: Book, back: () -> Unit) {
    BackHandler(onBack = back)
    val msgs by remember(book.id) { vm.msgs(book.id) }.collectAsState(emptyList())
    val lessons by vm.lessons.collectAsState()
    val st = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) st.animateScrollToItem(msgs.lastIndex) }
    Scaffold(topBar = {
        TopAppBar(title = { Text(book.assistantName, maxLines = 1) }, navigationIcon = { TextButton(back) { Text("←", fontSize = 22.sp) } })
    }) { p ->
        Column(Modifier.padding(p).fillMaxSize()) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = st, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(msgs, key = { it.id }) { m ->
                    val status = if (m.lessonId > 0) lessons.find { it.id == m.lessonId }?.status else null
                    Bubble(m, status, { vm.markDone(m.lessonId) }, { vm.later(m.lessonId) })
                }
            }
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("বার্তা লিখুন…") }, maxLines = 3)
                Spacer(Modifier.width(8.dp))
                Button({ if (input.isNotBlank()) { vm.userSay(book, input.trim()); input = "" } }) { Text("পাঠান") }
            }
        }
    }
}

@Composable
fun Library(vm: Vm) {
    val books by vm.books.collectAsState()
    val lessons by vm.lessons.collectAsState()
    var add by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Book?>(null) }
    Box(Modifier.fillMaxSize()) {
        if (books.isEmpty()) Text("লাইব্রেরি খালি। নিচের ＋ বাটনে চাপ দিয়ে বই যোগ করুন।", Modifier.align(Alignment.Center).padding(24.dp), textAlign = TextAlign.Center)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(books, key = { it.id }) { b ->
                val ls = lessons.filter { it.bookId == b.id }
                val done = ls.count { it.status == 2 }
                Card(Modifier.fillMaxWidth().clickable { sel = b }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(b.title, fontSize = 18.sp)
                        Text("${b.category}${if (b.author.isNotBlank()) " • " + b.author else ""} • মোট ${bn(ls.size)}টি পাঠ", fontSize = 13.sp)
                        LinearProgressIndicator(progress = { if (ls.isEmpty()) 0f else done.toFloat() / ls.size }, modifier = Modifier.fillMaxWidth())
                        Text("সম্পন্ন ${bn(done)}/${bn(ls.size)}", fontSize = 12.sp)
                    }
                }
            }
            item { Spacer(Modifier.height(72.dp)) }
        }
        FloatingActionButton({ add = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) { Text("＋", fontSize = 24.sp) }
    }
    if (add) AddBookDialog(vm) { add = false }
    sel?.let { BookDialog(vm, it) { sel = null } }
}

@Composable
fun AddBookDialog(vm: Vm, close: () -> Unit) {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fname by remember { mutableStateOf("") }
    var pasted by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("সাধারণ বই") }
    var mode by remember { mutableIntStateOf(0) }
    var n by remember { mutableStateOf("5") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { uri = u; fname = Importer.name(ctx, u); if (title.isBlank()) title = fname.substringBeforeLast('.') }
    }
    AlertDialog(onDismissRequest = { if (!busy) close() },
        title = { Text("নতুন বই / পাঠ্য যোগ করুন") },
        confirmButton = {
            Button(enabled = !busy && (uri != null || pasted.isNotBlank()), onClick = {
                busy = true; err = null
                vm.importBook(uri, pasted, title, author, cat, mode, n.toIntOrNull() ?: 5) { e -> busy = false; if (e == null) close() else err = e }
            }) { Text(if (busy) "অপেক্ষা করুন…" else "সংরক্ষণ") }
        },
        dismissButton = { TextButton({ if (!busy) close() }) { Text("বাতিল") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ picker.launch(arrayOf("*/*")) }) { Text(if (fname.isBlank()) "ফাইল বাছুন (PDF/TXT/EPUB/DOCX)" else "📄 $fname") }
                Text("অথবা লেখা পেস্ট করুন:", fontSize = 13.sp)
                OutlinedTextField(pasted, { pasted = it }, Modifier.fillMaxWidth(), minLines = 3, maxLines = 6)
                OutlinedTextField(title, { title = it }, label = { Text("বইয়ের নাম") }, singleLine = true)
                OutlinedTextField(author, { author = it }, label = { Text("লেখক") }, singleLine = true)
                Text("বিভাগ:", fontSize = 13.sp)
                listOf("সাধারণ বই", "কুরআন", "হাদিস", "ইংরেজি", "গণিত").chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { c ->
                            FilterChip(cat == c, { cat = c; if (c == "কুরআন" || c == "হাদিস") { mode = 2 } }, { Text(c) })
                        }
                    }
                }
                Text("পাঠ ভাগ করার নিয়ম:", fontSize = 13.sp)
                listOf("প্রতি পাঠে N পৃষ্ঠা/অনুচ্ছেদ", "প্রতি পাঠে N শব্দ", "নম্বর ধরে (আয়াত/হাদিস) N টি").forEachIndexed { i, l ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(mode == i, { mode = i; n = if (i == 1) "200" else "5" }); Text(l, fontSize = 14.sp)
                    }
                }
                OutlinedTextField(n, { n = it.filter { c -> c.isDigit() } }, label = { Text("N = ") }, singleLine = true)
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        })
}

@Composable
fun BookDialog(vm: Vm, b: Book, close: () -> Unit) {
    val ctx = LocalContext.current
    val scheds by vm.scheds.collectAsState()
    val mine = scheds.filter { it.bookId == b.id }.sortedBy { it.hour * 60 + it.minute }
    var confirm by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = close, title = { Text(b.title) },
        confirmButton = { TextButton(close) { Text("বন্ধ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("এই বইয়ের সময়সূচি:")
                if (mine.isEmpty()) Text("কোনো সময় ঠিক করা নেই", fontSize = 13.sp)
                mine.forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(timeLabel(s.hour, s.minute), Modifier.weight(1f))
                        Switch(s.enabled, { vm.toggleSched(s, it) })
                        TextButton({ vm.delSched(s) }) { Text("🗑") }
                    }
                }
                Button({ TimePickerDialog(ctx, { _, h, m -> vm.addSched(b.id, h, m) }, 9, 0, false).show() }) { Text("＋ নতুন সময় যোগ করুন") }
                OutlinedButton({ vm.sendNow(b.id); close() }) { Text("এখনই পরবর্তী পাঠ পাঠাও") }
                if (!confirm) TextButton({ confirm = true }) { Text("বইটি মুছে ফেলুন", color = MaterialTheme.colorScheme.error) }
                else Button({ vm.delBook(b); close() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("হ্যাঁ, নিশ্চিত মুছুন") }
            }
        })
}

@Composable
fun ProgressScreen(vm: Vm) {
    val lessons by vm.lessons.collectAsState()
    val books by vm.books.collectAsState()
    val now = System.currentTimeMillis()
    val d0 = startOfDay(now)
    val done = lessons.filter { it.status == 2 }
    val pend = lessons.filter { it.status == 1 || it.status == 3 }
    val days = (0..6).map { i -> var s = d0; repeat(i) { s = startOfDay(prevDay(s)) }; s }
    val week = days.map { s -> done.count { it.doneAt >= s && it.doneAt < s + 86_400_000L } }
    val month = done.count { it.doneAt >= d0 - 29 * 86_400_000L }
    val fmt = remember { SimpleDateFormat("d MMM", Locale.forLanguageTag("bn")) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("অগ্রগতি", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat("মোট বই", bn(books.size), Modifier.weight(1f)); Stat("মোট পাঠ", bn(lessons.size), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stat("সম্পন্ন", bn(done.size), Modifier.weight(1f)); Stat("অসম্পূর্ণ", bn(pend.size), Modifier.weight(1f))
                Stat("ধারাবাহিক দিন", bn(streak(lessons, now)), Modifier.weight(1f))
            }
        }
        item { Text("সাপ্তাহিক: ${bn(week.sum())}টি • মাসিক: ${bn(month)}টি") }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("গত ৭ দিন (দৈনিক সম্পন্ন)")
                    days.forEachIndexed { i, s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(bn(fmt.format(Date(s))), Modifier.width(70.dp), fontSize = 13.sp)
                            LinearProgressIndicator(progress = { (week[i] / 10f).coerceIn(0f, 1f) }, modifier = Modifier.weight(1f))
                            Text(" ${bn(week[i])}", fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        item { Text("বই অনুযায়ী অগ্রগতি", fontSize = 18.sp) }
        items(books, key = { "b${it.id}" }) { b ->
            val ls = lessons.filter { it.bookId == b.id }; val dn = ls.count { it.status == 2 }
            Column { Text("${b.title}: ${bn(dn)}/${bn(ls.size)}", fontSize = 14.sp)
                LinearProgressIndicator(progress = { if (ls.isEmpty()) 0f else dn.toFloat() / ls.size }, modifier = Modifier.fillMaxWidth()) }
        }
        item { Text("অসম্পূর্ণ পড়ার তালিকা", fontSize = 18.sp) }
        if (pend.isEmpty()) item { Text("কোনো অসম্পূর্ণ পড়া নেই 🎉") }
        items(pend.sortedBy { it.sentAt }, key = { "l${it.id}" }) { l ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(books.find { it.id == l.bookId }?.title ?: "", fontSize = 13.sp)
                        Text(l.title, fontSize = 16.sp)
                    }
                    Button({ vm.markDone(l.id) }) { Text("সম্পন্ন") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: Vm, theme: Int, setTheme: (Int) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var lock by remember { mutableStateOf(prefs.getBoolean("lock", false)) }
    val scheds by vm.scheds.collectAsState()
    val books by vm.books.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("সেটিংস", fontSize = 24.sp, color = MaterialTheme.colorScheme.primary) }
        item { Text("থিম") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("সিস্টেম", "লাইট", "ডার্ক").forEachIndexed { i, l -> FilterChip(theme == i, { setTheme(i) }, { Text(l) }) }
            }
        }
        item { HorizontalDivider() }
        item { Text("ইউটিউব বন্ধের ব্যবস্থা", fontSize = 18.sp) }
        item { Text("টাইমার শেষে ভিডিও পজ হবে। ইউটিউব থেকে বের হতে ও স্ক্রিন লক করতে অ্যাক্সেসিবিলিটি সেবা চালু করতে হবে (\"আমার সহকারী – ইউটিউব বন্ধ\")।", fontSize = 13.sp) }
        item { Button({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("অ্যাক্সেসিবিলিটি সেটিংস খুলুন") } }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("সময় শেষে স্ক্রিন লক করুন", Modifier.weight(1f))
                Switch(lock, { lock = it; prefs.edit().putBoolean("lock", it).apply() })
            }
        }
        if (Build.VERSION.SDK_INT >= 31) item {
            OutlinedButton({
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("সঠিক সময়ে অ্যালার্মের অনুমতি দিন") }
        }
        item { HorizontalDivider() }
        item { Text("কেন্দ্রীয় সময়সূচি", fontSize = 18.sp) }
        if (scheds.isEmpty()) item { Text("কোনো সময়সূচি নেই। লাইব্রেরিতে বই ছুঁয়ে সময় যোগ করুন।", fontSize = 13.sp) }
        items(scheds.sortedBy { it.hour * 60 + it.minute }, key = { it.id }) { s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(timeLabel(s.hour, s.minute), fontSize = 17.sp)
                    Text(books.find { it.id == s.bookId }?.title ?: "", fontSize = 13.sp)
                }
                Switch(s.enabled, { vm.toggleSched(s, it) })
                TextButton({ vm.delSched(s) }) { Text("🗑") }
            }
        }
    }
}
